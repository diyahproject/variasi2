import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Upload, 
  Image as ImageIcon, 
  Trash2, 
  Search, 
  RefreshCw,
  Download,
  Copy,
  Check,
  X,
  FileImage,
  File
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface MediaFile {
  id: string;
  filename: string;
  original_name: string;
  file_path: string;
  file_size: number;
  mime_type: string;
  uploaded_by: string;
  is_active: boolean;
  created_at: string;
}

export function MediaManager() {
  const [files, setFiles] = useState<MediaFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchFiles();
  }, []);

  const fetchFiles = async () => {
    try {
      // Demo files
      const demoFiles: MediaFile[] = [
        {
          id: '1',
          filename: 'hero-image.jpg',
          original_name: 'hero-image.jpg',
          file_path: '/uploads/hero-image.jpg',
          file_size: 2048000,
          mime_type: 'image/jpeg',
          uploaded_by: 'admin',
          is_active: true,
          created_at: new Date().toISOString()
        }
      ];
      setFiles(demoFiles);
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Gagal memuat file media",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File Terlalu Besar",
        description: "Ukuran file maksimal 5MB",
        variant: "destructive"
      });
      return;
    }

    // Check file type
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      toast({
        title: "Format File Tidak Didukung",
        description: "Hanya mendukung format: JPG, PNG, GIF, WebP",
        variant: "destructive"
      });
      return;
    }

    setUploading(true);
    
    try {
      // For demo purposes, we'll create a fake file entry
      // In real implementation, you would upload to storage
      const filename = `${Date.now()}_${file.name}`;
      const filePath = `/uploads/${filename}`;
      
      // For demo, just add to local state
      const newFile: MediaFile = {
        id: Date.now().toString(),
        filename,
        original_name: file.name,
        file_path: filePath,
        file_size: file.size,
        mime_type: file.type,
        uploaded_by: JSON.parse(sessionStorage.getItem('adminLogin') || '{}').userId || 'admin',
        is_active: true,
        created_at: new Date().toISOString()
      };
      
      setFiles([newFile, ...files]);
      
      toast({
        title: "Upload Berhasil",
        description: `File ${file.name} berhasil diupload (demo)`
      });

      // Reset file input
      event.target.value = '';
    } catch (error: any) {
      toast({
        title: "Upload Gagal",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setUploading(false);
    }
  };

  const deleteFile = async (fileId: string) => {
    try {
      // For demo, just update local state
      setFiles(files.map(file => 
        file.id === fileId 
          ? { ...file, is_active: false }
          : file
      ));
      
      toast({
        title: "File Dihapus",
        description: "File berhasil dihapus"
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Gagal menghapus file",
        variant: "destructive"
      });
    }
  };

  const copyToClipboard = async (text: string, fileId: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(fileId);
      setTimeout(() => setCopiedId(null), 2000);
      
      toast({
        title: "Copied!",
        description: "URL file telah disalin"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Gagal menyalin URL",
        variant: "destructive"
      });
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (mimeType: string) => {
    if (mimeType.startsWith('image/')) {
      return FileImage;
    }
    return File;
  };

  const filteredFiles = files.filter(file => 
    file.is_active && 
    (file.original_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
     file.filename.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Media Manager</h2>
          <p className="text-muted-foreground">Upload dan kelola file media</p>
        </div>
        <Button
          variant="outline"
          onClick={fetchFiles}
          className="flex items-center gap-2"
        >
          <RefreshCw className="h-4 w-4" />
          Refresh
        </Button>
      </div>

      {/* Upload Section */}
      <Card className="border-0 shadow-md bg-card/95 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Upload File Baru
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="border-2 border-dashed border-border/50 rounded-lg p-8 text-center hover:border-primary/50 transition-colors">
              <input
                type="file"
                id="file-upload"
                className="hidden"
                accept="image/*"
                onChange={handleFileUpload}
                disabled={uploading}
              />
              <label 
                htmlFor="file-upload" 
                className="cursor-pointer flex flex-col items-center gap-4"
              >
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                  {uploading ? (
                    <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <ImageIcon className="h-8 w-8 text-primary" />
                  )}
                </div>
                <div>
                  <p className="text-lg font-medium">
                    {uploading ? 'Mengupload...' : 'Klik untuk upload file'}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Format: JPG, PNG, GIF, WebP (Max 5MB)
                  </p>
                </div>
              </label>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Search */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Cari file..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Badge variant="outline" className="px-3 py-1">
          {filteredFiles.length} file
        </Badge>
      </div>

      {/* Files Grid */}
      {filteredFiles.length === 0 ? (
        <Card className="border-0 shadow-md bg-card/95 backdrop-blur-sm">
          <CardContent className="py-12 text-center">
            <ImageIcon className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <p className="text-lg text-muted-foreground">
              {searchTerm ? 'Tidak ada file yang ditemukan' : 'Belum ada file yang diupload'}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredFiles.map((file) => {
            const FileIconComponent = getFileIcon(file.mime_type);
            return (
              <motion.div
                key={file.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3 }}
              >
                <Card className="border-0 shadow-md bg-card/95 backdrop-blur-sm hover:shadow-lg transition-shadow group">
                  <CardContent className="p-4">
                    <div className="aspect-square bg-muted/30 rounded-lg mb-3 flex items-center justify-center overflow-hidden">
                      {file.mime_type.startsWith('image/') ? (
                        <div className="w-full h-full bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center">
                          <FileIconComponent className="h-12 w-12 text-primary" />
                        </div>
                      ) : (
                        <FileIconComponent className="h-12 w-12 text-muted-foreground" />
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <h4 className="font-medium text-sm truncate" title={file.original_name}>
                        {file.original_name}
                      </h4>
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>{formatFileSize(file.file_size)}</span>
                        <span>{new Date(file.created_at).toLocaleDateString('id-ID')}</span>
                      </div>
                      
                      <div className="flex items-center gap-1 pt-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(file.file_path, file.id)}
                          className="flex-1 text-xs h-8"
                        >
                          {copiedId === file.id ? (
                            <Check className="h-3 w-3" />
                          ) : (
                            <Copy className="h-3 w-3" />
                          )}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteFile(file.id)}
                          className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}