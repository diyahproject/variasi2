import { useState, useEffect } from "react";
import { AdminCRUD } from "./AdminCRUD";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Download, 
  FileText, 
  ExternalLink,
  Upload,
  Star
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

export function DownloadManager() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Set up real-time subscriptions
    const downloadsChannel = supabase
      .channel('downloads-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'downloads' }, () => {
        toast({ title: "Data diperbarui", description: "Perubahan tersimpan ke database" });
      })
      .subscribe();
    
    const sourcesChannel = supabase
      .channel('sources-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'external_sources' }, () => {
        toast({ title: "Data diperbarui", description: "Perubahan tersimpan ke database" });
      })
      .subscribe();

    setLoading(false);

    return () => {
      supabase.removeChannel(downloadsChannel);
      supabase.removeChannel(sourcesChannel);
    };
  }, [toast]);

  const downloadFields = [
    { name: 'title', label: 'Judul File *', type: 'text' as const, required: true },
    { name: 'description', label: 'Deskripsi Singkat', type: 'textarea' as const },
    { name: 'file_format', label: 'Format File *', type: 'text' as const, required: true },
    { name: 'file_size', label: 'Ukuran File', type: 'text' as const },
    { name: 'file_url', label: 'File (max 10MB)', type: 'file' as const },
    { name: 'sort_order', label: 'Urutan Tampil', type: 'number' as const },
    { name: 'is_active', label: 'Aktif', type: 'boolean' as const }
  ];

  const externalSourceFields = [
    { name: 'title', label: 'Judul Sumber *', type: 'text' as const, required: true },
    { name: 'description', label: 'Deskripsi Sumber', type: 'textarea' as const },
    { name: 'link_url', label: 'URL Link *', type: 'text' as const, required: true },
    { name: 'button_label', label: 'Label Tombol', type: 'text' as const },
    { name: 'sort_order', label: 'Urutan Tampil', type: 'number' as const },
    { name: 'is_active', label: 'Aktif', type: 'boolean' as const }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Download className="h-6 w-6" />
            Manajemen Download
          </h2>
          <p className="text-muted-foreground">Kelola file download dan sumber eksternal</p>
        </div>
      </div>

      <Tabs defaultValue="files" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="files" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Materi Download
          </TabsTrigger>
          <TabsTrigger value="external" className="flex items-center gap-2">
            <ExternalLink className="h-4 w-4" />
            Sumber Eksternal
          </TabsTrigger>
        </TabsList>

        <TabsContent value="files" className="space-y-6">
          <Card className="border-0 shadow-md bg-card/95 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Materi Download
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-4 p-4 bg-primary/5 border border-primary/20 rounded-lg">
                <h4 className="font-medium mb-2">📚 Panduan File Download:</h4>
                <ul className="text-sm space-y-1 text-muted-foreground">
                  <li>• <strong>Judul file:</strong> Nama yang akan ditampilkan kepada pengguna</li>
                  <li>• <strong>Format file:</strong> PDF, ZIP, DOC, dll</li>
                  <li>• <strong>Deskripsi:</strong> Ringkasan singkat tentang isi file</li>
                  <li>• <strong>Ukuran file:</strong> Contoh: 2.5 MB, 1.2 GB</li>
                  <li>• <strong>Upload file:</strong> Maksimal 10MB per file</li>
                  <li>• <strong>Tracking download:</strong> Sistem akan menghitung jumlah download otomatis</li>
                </ul>
              </div>
              
              <AdminCRUD
                table="downloads"
                title="File Download"
                fields={downloadFields}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="external" className="space-y-6">
          <Card className="border-0 shadow-md bg-card/95 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ExternalLink className="h-5 w-5" />
                Sumber Eksternal
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-4 p-4 bg-primary/5 border border-primary/20 rounded-lg">
                <h4 className="font-medium mb-2">🔗 Panduan Sumber Eksternal:</h4>
                <ul className="text-sm space-y-1 text-muted-foreground">
                  <li>• <strong>Judul sumber:</strong> Nama website atau sumber referensi</li>
                  <li>• <strong>Deskripsi:</strong> Penjelasan tentang konten yang tersedia</li>
                  <li>• <strong>URL Link:</strong> Link lengkap ke sumber eksternal</li>
                  <li>• <strong>Label tombol:</strong> Teks pada tombol (default: "Kunjungi")</li>
                  <li>• <strong>Urutan tampil:</strong> Angka kecil akan tampil lebih atas</li>
                </ul>
              </div>
              
              <AdminCRUD
                table="external_sources"
                title="Sumber Eksternal"
                fields={externalSourceFields}
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Download Features Info */}
      <Card className="border-0 shadow-md bg-gradient-to-r from-primary/5 to-secondary/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="h-5 w-5" />
            Fitur Download yang Tersedia
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <h4 className="font-medium flex items-center gap-2">
                <Upload className="h-4 w-4" />
                Upload Otomatis
              </h4>
              <p className="text-sm text-muted-foreground">
                Validasi format dan ukuran file dengan preview
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium flex items-center gap-2">
                <Download className="h-4 w-4" />
                Tracking Download
              </h4>
              <p className="text-sm text-muted-foreground">
                Sistem menghitung jumlah download setiap file
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium flex items-center gap-2">
                <ExternalLink className="h-4 w-4" />
                Link Eksternal
              </h4>
              <p className="text-sm text-muted-foreground">
                Referensi ke sumber lain dengan label kustom
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}