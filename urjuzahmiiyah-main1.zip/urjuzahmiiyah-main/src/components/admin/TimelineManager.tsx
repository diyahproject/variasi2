import { useState, useEffect } from "react";
import { AdminCRUD } from "./AdminCRUD";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Clock, 
  Calendar, 
  MapPin, 
  Users, 
  BookOpen, 
  Star,
  Plus,
  Edit3,
  Trash2,
  Upload,
  Move
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const hijriMonths = [
  'Muharram', 'Safar', 'Rabi\'ul Awwal', 'Rabi\'ul Akhir',
  'Jumadal Awwal', 'Jumadal Akhir', 'Rajab', 'Sha\'ban',
  'Ramadan', 'Shawwal', 'Zulqa\'dah', 'Zulhijjah'
];

export function TimelineManager() {
  const { toast } = useToast();

  const hijriYearFields = [
    { name: 'year_number', label: 'Nomor Tahun Hijriah *', type: 'number' as const },
    { name: 'image_url', label: 'Gambar Ilustrasi (max 1MB)', type: 'file' as const },
    { name: 'is_active', label: 'Aktif', type: 'boolean' as const }
  ];

  const eventFields = [
    { name: 'title', label: 'Judul Peristiwa *', type: 'text' as const },
    { name: 'subtitle', label: 'Subjudul/Ringkasan', type: 'text' as const },
    { name: 'description', label: 'Deskripsi Peristiwa *', type: 'textarea' as const },
    { name: 'hijri_year', label: 'Tahun Hijriah *', type: 'number' as const },
    { name: 'hijri_month', label: 'Bulan Hijriah', type: 'select' as const, options: hijriMonths },
    { name: 'location', label: 'Lokasi (Nama Kota)', type: 'text' as const },
    { name: 'latitude', label: 'Koordinat Latitude', type: 'number' as const },
    { name: 'longitude', label: 'Koordinat Longitude', type: 'number' as const },
    { name: 'duration', label: 'Durasi (contoh: 3 hari, 1 bulan)', type: 'text' as const },
    { name: 'participants', label: 'Pihak Terlibat (pisahkan dengan koma)', type: 'tags' as const },
    { name: 'trivia', label: 'Trivia/Fakta Menarik (pisahkan dengan koma)', type: 'tags' as const },
    { name: 'event_references', label: 'Referensi (pisahkan dengan koma)', type: 'tags' as const },
    { name: 'image_url', label: 'Gambar/Ikon Peristiwa', type: 'text' as const },
    { name: 'category_id', label: 'Kategori', type: 'relation' as const, table: 'categories' },
    { name: 'is_active', label: 'Aktif', type: 'boolean' as const }
  ];

  const categoryFields = [
    { name: 'name', label: 'Nama Kategori *', type: 'text' as const },
    { name: 'description', label: 'Deskripsi Kategori', type: 'textarea' as const },
    { name: 'badge_text', label: 'Teks Badge', type: 'text' as const },
    { name: 'image_url', label: 'Ikon Kategori', type: 'text' as const },
    { name: 'sort_order', label: 'Urutan Tampil', type: 'number' as const },
    { name: 'is_active', label: 'Aktif', type: 'boolean' as const }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Clock className="h-6 w-6" />
            Manajemen Timeline Sejarah Islam
          </h2>
          <p className="text-muted-foreground">Kelola tahun Hijriah, peristiwa, dan kategori sejarah</p>
        </div>
      </div>

      <Tabs defaultValue="years" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="years" className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            Tahun Hijriah
          </TabsTrigger>
          <TabsTrigger value="events" className="flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            Peristiwa
          </TabsTrigger>
          <TabsTrigger value="categories" className="flex items-center gap-2">
            <BookOpen className="h-4 w-4" />
            Kategori
          </TabsTrigger>
        </TabsList>

        <TabsContent value="years" className="space-y-6">
          <Card className="border-0 shadow-md bg-card/95 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Manajemen Tahun Hijriah
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-4 p-4 bg-primary/5 border border-primary/20 rounded-lg">
                <h4 className="font-medium mb-2">📌 Panduan Struktur per Tahun:</h4>
                <ul className="text-sm space-y-1 text-muted-foreground">
                  <li>• <strong>Nomor tahun Hijriah:</strong> Tahun dalam kalender Hijriah (contoh: 1, 2, 622)</li>
                  <li>• <strong>Gambar ilustrasi:</strong> Upload gambar maksimal 1MB untuk representasi tahun</li>
                  <li>• <strong>Sistem tag:</strong> Pengelompokan peristiwa otomatis berdasarkan kategori aktif</li>
                </ul>
              </div>
              
              <AdminCRUD
                table="hijri_years"
                title="Tahun Hijriah"
                fields={hijriYearFields}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="events" className="space-y-6">
          <Card className="border-0 shadow-md bg-card/95 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Manajemen Peristiwa Sejarah
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-4 p-4 bg-primary/5 border border-primary/20 rounded-lg">
                <h4 className="font-medium mb-2">📌 Panduan Struktur per Peristiwa:</h4>
                <ul className="text-sm space-y-1 text-muted-foreground">
                  <li>• <strong>Judul & Subjudul:</strong> Nama peristiwa dan ringkasan singkat</li>
                  <li>• <strong>Lokasi & Koordinat:</strong> Nama kota dan titik koordinat untuk peta interaktif</li>
                  <li>• <strong>Waktu:</strong> Tahun dan bulan Hijriah</li>
                  <li>• <strong>Pihak Terlibat:</strong> Pisahkan dengan koma (Muslimin, Quraisy, dll)</li>
                  <li>• <strong>Trivia:</strong> Fakta menarik terkait peristiwa</li>
                  <li>• <strong>Referensi:</strong> Sumber-sumber yang dapat dipercaya</li>
                </ul>
              </div>

              <AdminCRUD
                table="events"
                title="Peristiwa Sejarah"
                fields={eventFields}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="categories" className="space-y-6">
          <Card className="border-0 shadow-md bg-card/95 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Manajemen Kategori Peristiwa
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-4 p-4 bg-primary/5 border border-primary/20 rounded-lg">
                <h4 className="font-medium mb-2">📌 Fitur Kategori:</h4>
                <ul className="text-sm space-y-1 text-muted-foreground">
                  <li>• <strong>Nama kategori:</strong> Contoh: Perang, Dakwah, Pemerintahan</li>
                  <li>• <strong>Badge text:</strong> Teks pendek untuk label</li>
                  <li>• <strong>Ikon:</strong> URL gambar ikon (pedang, mahkota, dll)</li>
                  <li>• <strong>Urutan tampil:</strong> Angka untuk mengatur urutan kategori</li>
                  <li>• <strong>Drag & drop:</strong> Fitur pengaturan urutan akan tersedia</li>
                </ul>
              </div>

              <AdminCRUD
                table="categories"
                title="Kategori Peristiwa"
                fields={categoryFields}
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Timeline Features Info */}
      <Card className="border-0 shadow-md bg-gradient-to-r from-primary/5 to-secondary/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="h-5 w-5" />
            Fitur Timeline yang Tersedia
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <h4 className="font-medium flex items-center gap-2">
                <MapPin className="h-4 w-4" />
                Peta Interaktif
              </h4>
              <p className="text-sm text-muted-foreground">
                Animasi zoom out ke lokasi peristiwa berdasarkan koordinat
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium flex items-center gap-2">
                <Users className="h-4 w-4" />
                Multi-tag Pihak
              </h4>
              <p className="text-sm text-muted-foreground">
                Sistem tag untuk mengelompokkan pihak yang terlibat
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium flex items-center gap-2">
                <Move className="h-4 w-4" />
                Drag & Drop
              </h4>
              <p className="text-sm text-muted-foreground">
                Ubah urutan peristiwa dalam satu tahun dengan mudah
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}