import { useState, useEffect } from "react";
import { AdminCRUD } from "./AdminCRUD";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Upload, Home, Save, Eye } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface HeroSection {
  id: string;
  title: string;
  subtitle: string;
  cta_text: string;
  cta_link: string;
  background_image: string;
  main_image: string;
  is_active: boolean;
}

export function HomepageManager() {
  const [heroSections, setHeroSections] = useState<HeroSection[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingHero, setEditingHero] = useState<HeroSection | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    subtitle: '',
    cta_text: '',
    cta_link: '',
    background_image: '',
    main_image: ''
  });
  const { toast } = useToast();

  useEffect(() => {
    fetchHeroSections();
    
    // Set up real-time subscription for hero sections
    const channel = supabase
      .channel('hero-sections-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'hero_sections'
        },
        () => {
          fetchHeroSections();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchHeroSections = async () => {
    try {
      const { data, error } = await supabase
        .from('hero_sections')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setHeroSections(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Gagal memuat data hero section",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (hero: HeroSection) => {
    setEditingHero(hero);
    setFormData({
      title: hero.title || '',
      subtitle: hero.subtitle || '',
      cta_text: hero.cta_text || '',
      cta_link: hero.cta_link || '',
      background_image: hero.background_image || '',
      main_image: hero.main_image || ''
    });
  };

  const handleSave = async () => {
    if (!editingHero) return;

    try {
      const { error } = await supabase
        .from('hero_sections')
        .update(formData)
        .eq('id', editingHero.id);

      if (error) throw error;

      toast({
        title: "Berhasil",
        description: "Hero section berhasil diperbarui"
      });

      await fetchHeroSections();
      setEditingHero(null);
      setFormData({
        title: '',
        subtitle: '',
        cta_text: '',
        cta_link: '',
        background_image: '',
        main_image: ''
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const handleImageUpload = async (field: string, file: File) => {
    // Validate file size (max 1MB)
    if (file.size > 1024 * 1024) {
      toast({
        title: "File Terlalu Besar",
        description: "Ukuran file maksimal 1MB",
        variant: "destructive"
      });
      return;
    }

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Format File Salah",
        description: "Hanya file gambar yang diperbolehkan",
        variant: "destructive"
      });
      return;
    }

    // For demo, create object URL
    const imageUrl = URL.createObjectURL(file);
    setFormData(prev => ({
      ...prev,
      [field]: imageUrl
    }));

    toast({
      title: "Gambar Berhasil Diupload",
      description: "Jangan lupa simpan perubahan"
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Home className="h-6 w-6" />
            Manajemen Homepage
          </h2>
          <p className="text-muted-foreground">Kelola konten halaman utama website</p>
        </div>
      </div>

      {/* Hero Section Management */}
      <Card className="border-0 shadow-md bg-card/95 backdrop-blur-sm">
        <CardHeader>
          <CardTitle>Hero Section</CardTitle>
        </CardHeader>
        <CardContent>
          {heroSections.length > 0 ? (
            <div className="space-y-6">
              {heroSections.map((hero) => (
                <div key={hero.id} className="space-y-4 p-4 border rounded-lg">
                  {editingHero?.id === hero.id ? (
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="title">Judul Utama *</Label>
                          <Input
                            id="title"
                            value={formData.title}
                            onChange={(e) => setFormData({...formData, title: e.target.value})}
                            placeholder="Masukkan judul halaman utama"
                          />
                        </div>
                        <div>
                          <Label htmlFor="subtitle">Subjudul/Deskripsi *</Label>
                          <Input
                            id="subtitle"
                            value={formData.subtitle}
                            onChange={(e) => setFormData({...formData, subtitle: e.target.value})}
                            placeholder="Masukkan subjudul"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="cta_text">Teks Tombol</Label>
                          <Input
                            id="cta_text"
                            value={formData.cta_text}
                            onChange={(e) => setFormData({...formData, cta_text: e.target.value})}
                            placeholder="Contoh: Jelajahi Timeline"
                          />
                        </div>
                        <div>
                          <Label htmlFor="cta_link">Link Navigasi</Label>
                          <Input
                            id="cta_link"
                            value={formData.cta_link}
                            onChange={(e) => setFormData({...formData, cta_link: e.target.value})}
                            placeholder="/timeline atau https://example.com"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="background_image">Gambar Latar</Label>
                          <div className="flex gap-2">
                            <Input
                              id="background_image"
                              value={formData.background_image}
                              onChange={(e) => setFormData({...formData, background_image: e.target.value})}
                              placeholder="URL gambar latar"
                            />
                            <input
                              type="file"
                              accept="image/*"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) handleImageUpload('background_image', file);
                              }}
                              className="hidden"
                              id="bg-upload"
                            />
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => document.getElementById('bg-upload')?.click()}
                            >
                              <Upload className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="main_image">Gambar dalam Frame</Label>
                          <div className="flex gap-2">
                            <Input
                              id="main_image"
                              value={formData.main_image}
                              onChange={(e) => setFormData({...formData, main_image: e.target.value})}
                              placeholder="URL gambar utama"
                            />
                            <input
                              type="file"
                              accept="image/*"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) handleImageUpload('main_image', file);
                              }}
                              className="hidden"
                              id="main-upload"
                            />
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => document.getElementById('main-upload')?.click()}
                            >
                              <Upload className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <Button onClick={handleSave}>
                          <Save className="h-4 w-4 mr-2" />
                          Simpan Perubahan
                        </Button>
                        <Button variant="outline" onClick={() => setEditingHero(null)}>
                          Batal
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-lg font-semibold">{hero.title}</h3>
                          <p className="text-muted-foreground">{hero.subtitle}</p>
                          {hero.cta_text && (
                            <p className="text-sm">
                              Tombol: "{hero.cta_text}" → {hero.cta_link}
                            </p>
                          )}
                        </div>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" onClick={() => handleEdit(hero)}>
                            Edit
                          </Button>
                        </div>
                      </div>
                      
                      {(hero.background_image || hero.main_image) && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {hero.background_image && (
                            <div>
                              <Label>Gambar Latar:</Label>
                              <div className="mt-1 p-2 border rounded bg-muted/20">
                                <img src={hero.background_image} alt="Background" className="w-full h-20 object-cover rounded" />
                              </div>
                            </div>
                          )}
                          {hero.main_image && (
                            <div>
                              <Label>Gambar Frame:</Label>
                              <div className="mt-1 p-2 border rounded bg-muted/20">
                                <img src={hero.main_image} alt="Main" className="w-full h-20 object-cover rounded" />
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <p>Belum ada hero section. Silakan tambahkan melalui database.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Welcome Popup Management */}
      <AdminCRUD
        table="welcome_popup"
        title="Welcome Popup"
        fields={[
          { name: 'cta_text', label: 'Teks Tombol', type: 'text' },
          { name: 'lottie_url', label: 'URL Animasi Lottie', type: 'text' },
          { name: 'is_active', label: 'Aktif', type: 'boolean' }
        ]}
      />
    </div>
  );
}