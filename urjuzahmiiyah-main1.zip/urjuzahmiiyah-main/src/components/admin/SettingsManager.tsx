import { useState, useEffect } from "react";
import { AdminCRUD } from "./AdminCRUD";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Settings, 
  HelpCircle, 
  MessageSquare, 
  Info, 
  Users,
  Star,
  Mail,
  Check,
  AlertCircle,
  Plus,
  Edit3,
  Trash2,
  Upload,
  MoveUp,
  MoveDown
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface FAQ {
  id: string;
  question: string;
  answer: string;
  sort_order: number;
  is_active: boolean;
}

interface Feedback {
  id: string;
  name: string;
  email: string;
  message: string;
  is_read: boolean;
  created_at: string;
}

interface AboutUs {
  id: string;
  title: string;
  content: string;
  mission: string;
  team_info: any;
  is_active: boolean;
}

interface TeamMember {
  name: string;
  position: string;
  description: string;
  photo_url: string;
}

export function SettingsManager() {
  const [faqs, setFaqs] = useState<FAQ[]>([]);
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [aboutUs, setAboutUs] = useState<AboutUs[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('faq');
  const { toast } = useToast();

  useEffect(() => {
    fetchData();
    
    // Set up real-time subscriptions
    const faqChannel = supabase
      .channel('faq-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'faqs' }, fetchData)
      .subscribe();
    
    const feedbackChannel = supabase
      .channel('feedback-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'feedback' }, fetchData)
      .subscribe();
    
    const aboutChannel = supabase
      .channel('about-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'about_us' }, fetchData)
      .subscribe();

    const teamChannel = supabase
      .channel('team-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'team_members' }, fetchData)
      .subscribe();

    return () => {
      supabase.removeChannel(faqChannel);
      supabase.removeChannel(feedbackChannel);
      supabase.removeChannel(aboutChannel);
      supabase.removeChannel(teamChannel);
    };
  }, []);

  const fetchData = async () => {
    try {
      // Fetch FAQs
      const { data: faqData, error: faqError } = await supabase
        .from('faqs')
        .select('*')
        .order('sort_order', { ascending: true });

      if (faqError) throw faqError;
      setFaqs(faqData || []);

      // Fetch Feedback
      const { data: feedbackData, error: feedbackError } = await supabase
        .from('feedback')
        .select('*')
        .order('created_at', { ascending: false });

      if (feedbackError) throw feedbackError;
      setFeedbacks(feedbackData || []);

      // Fetch About Us
      const { data: aboutData, error: aboutError } = await supabase
        .from('about_us')
        .select('*')
        .order('updated_at', { ascending: false });

      if (aboutError) throw aboutError;
      setAboutUs(aboutData || []);

    } catch (error: any) {
      toast({
        title: "Error",
        description: "Gagal memuat data pengaturan",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const markFeedbackAsRead = async (feedbackId: string) => {
    try {
      const { error } = await supabase
        .from('feedback')
        .update({ is_read: true })
        .eq('id', feedbackId);

      if (error) throw error;

      setFeedbacks(prev => 
        prev.map(feedback => 
          feedback.id === feedbackId 
            ? { ...feedback, is_read: true }
            : feedback
        )
      );

      toast({
        title: "Berhasil",
        description: "Feedback ditandai sebagai sudah dibaca"
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const updateFAQOrder = async (faqId: string, newOrder: number) => {
    try {
      const { error } = await supabase
        .from('faqs')
        .update({ sort_order: newOrder })
        .eq('id', faqId);

      if (error) throw error;

      await fetchData();
      
      toast({
        title: "Berhasil",
        description: "Urutan FAQ berhasil diperbarui"
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const faqFields = [
    { name: 'question', label: 'Pertanyaan *', type: 'text' as const },
    { name: 'answer', label: 'Jawaban *', type: 'textarea' as const },
    { name: 'sort_order', label: 'Urutan Tampil', type: 'number' as const },
    { name: 'is_active', label: 'Aktif', type: 'boolean' as const }
  ];

  const aboutUsFields = [
    { name: 'title', label: 'Judul Halaman *', type: 'text' as const },
    { name: 'content', label: 'Deskripsi Singkat *', type: 'textarea' as const },
    { name: 'mission', label: 'Misi *', type: 'textarea' as const },
    { name: 'is_active', label: 'Aktif', type: 'boolean' as const }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Settings className="h-6 w-6" />
            Manajemen Pengaturan
          </h2>
          <p className="text-muted-foreground">Kelola FAQ, feedback, dan informasi tentang kami</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="faq" className="flex items-center gap-2">
            <HelpCircle className="h-4 w-4" />
            FAQ
          </TabsTrigger>
          <TabsTrigger value="feedback" className="flex items-center gap-2">
            <MessageSquare className="h-4 w-4" />
            Feedback
          </TabsTrigger>
          <TabsTrigger value="about" className="flex items-center gap-2">
            <Info className="h-4 w-4" />
            Tentang Kami
          </TabsTrigger>
        </TabsList>

        <TabsContent value="faq" className="space-y-6">
          <Card className="border-0 shadow-md bg-card/95 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <HelpCircle className="h-5 w-5" />
                Manajemen FAQ
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-4 p-4 bg-primary/5 border border-primary/20 rounded-lg">
                <h4 className="font-medium mb-2">❓ Panduan FAQ:</h4>
                <ul className="text-sm space-y-1 text-muted-foreground">
                  <li>• <strong>Pertanyaan:</strong> Tulis pertanyaan yang sering ditanyakan pengguna</li>
                  <li>• <strong>Jawaban:</strong> Berikan jawaban yang jelas dan informatif</li>
                  <li>• <strong>Urutan:</strong> Angka kecil akan tampil lebih atas</li>
                  <li>• <strong>Drag & drop:</strong> Fitur pengaturan urutan tersedia untuk kemudahan</li>
                </ul>
              </div>

              {faqs.length > 0 && (
                <div className="mb-6">
                  <h4 className="font-medium mb-3">FAQ Aktif (dapat diurutkan):</h4>
                  <div className="space-y-2">
                    {faqs.filter(faq => faq.is_active).map((faq, index) => (
                      <div key={faq.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex-1">
                          <p className="font-medium">{faq.question}</p>
                          <p className="text-sm text-muted-foreground line-clamp-2">{faq.answer}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">#{faq.sort_order}</Badge>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => updateFAQOrder(faq.id, faq.sort_order - 1)}
                            disabled={index === 0}
                          >
                            <MoveUp className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => updateFAQOrder(faq.id, faq.sort_order + 1)}
                            disabled={index === faqs.filter(f => f.is_active).length - 1}
                          >
                            <MoveDown className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <AdminCRUD
                table="faqs"
                title="Daftar FAQ"
                fields={faqFields}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="feedback" className="space-y-6">
          <Card className="border-0 shadow-md bg-card/95 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Kritik & Saran
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-4 p-4 bg-primary/5 border border-primary/20 rounded-lg">
                <h4 className="font-medium mb-2">💬 Fitur Feedback:</h4>
                <ul className="text-sm space-y-1 text-muted-foreground">
                  <li>• <strong>Form otomatis:</strong> Pengguna dapat mengirim feedback melalui halaman /feedback</li>
                  <li>• <strong>Data tersimpan:</strong> Nama (opsional), email (opsional), dan pesan</li>
                  <li>• <strong>Status baca:</strong> Tandai sebagai sudah dibaca/penting</li>
                  <li>• <strong>Notifikasi:</strong> Feedback baru akan ternotifikasi di panel admin</li>
                </ul>
              </div>

              {feedbacks.length > 0 ? (
                <div className="space-y-4">
                  {feedbacks.map((feedback) => (
                    <div key={feedback.id} className="p-4 border rounded-lg space-y-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h4 className="font-medium">
                              {feedback.name || 'Anonim'}
                            </h4>
                            {feedback.email && (
                              <Badge variant="outline" className="text-xs">
                                <Mail className="h-3 w-3 mr-1" />
                                {feedback.email}
                              </Badge>
                            )}
                            <Badge 
                              variant={feedback.is_read ? "default" : "destructive"}
                              className={feedback.is_read ? "bg-green-500/10 text-green-600" : ""}
                            >
                              {feedback.is_read ? 'Sudah dibaca' : 'Belum dibaca'}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">
                            {new Date(feedback.created_at).toLocaleString('id-ID')}
                          </p>
                          <p className="text-sm">{feedback.message}</p>
                        </div>
                        {!feedback.is_read && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => markFeedbackAsRead(feedback.id)}
                            className="flex items-center gap-2"
                          >
                            <Check className="h-4 w-4" />
                            Tandai Dibaca
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <MessageSquare className="h-16 w-16 mx-auto mb-4 opacity-50" />
                  <p>Belum ada feedback dari pengguna</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="about" className="space-y-6">
          <Card className="border-0 shadow-md bg-card/95 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Info className="h-5 w-5" />
                Tentang Kami
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-4 p-4 bg-primary/5 border border-primary/20 rounded-lg">
                <h4 className="font-medium mb-2">ℹ️ Komponen Tentang Kami:</h4>
                <ul className="text-sm space-y-1 text-muted-foreground">
                  <li>• <strong>Judul halaman:</strong> "Tentang Kami" atau customize sesuai kebutuhan</li>
                  <li>• <strong>Deskripsi singkat:</strong> Gambaran umum tentang website/organisasi</li>
                  <li>• <strong>Misi:</strong> Visi dan misi website Urjuzah Miiyah</li>
                  <li>• <strong>Tim Inti:</strong> Modul repeater untuk anggota tim (nama, jabatan, deskripsi, foto)</li>
                </ul>
              </div>

              <AdminCRUD
                table="about_us"
                title="Informasi Tentang Kami"
                fields={aboutUsFields}
              />

              {/* Team Members Section */}
              <div className="mt-8">
                <Card className="border-0 shadow-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5" />
                      Tim Inti
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-4 p-4 bg-primary/5 border border-primary/20 rounded-lg">
                      <h4 className="font-medium mb-2">👥 Panduan Tim Inti:</h4>
                      <ul className="text-sm space-y-1 text-muted-foreground">
                        <li>• <strong>Nama & Jabatan:</strong> Informasi dasar anggota tim</li>
                        <li>• <strong>Deskripsi singkat:</strong> Latar belakang atau keahlian</li>
                        <li>• <strong>Foto profil:</strong> Upload gambar maksimal 1MB</li>
                        <li>• <strong>Urutan tampil:</strong> Angka kecil akan tampil lebih atas</li>
                      </ul>
                    </div>
                    
                    <AdminCRUD
                      table="team_members"
                      title="Anggota Tim Inti"
                      fields={[
                        { name: 'name', label: 'Nama Lengkap *', type: 'text' },
                        { name: 'position', label: 'Jabatan *', type: 'text' },
                        { name: 'description', label: 'Deskripsi Singkat', type: 'textarea' },
                        { name: 'photo_url', label: 'Foto Profil (max 1MB)', type: 'file' },
                        { name: 'sort_order', label: 'Urutan Tampil', type: 'number' },
                        { name: 'is_active', label: 'Aktif', type: 'boolean' }
                      ]}
                    />
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Settings Features Summary */}
      <Card className="border-0 shadow-md bg-gradient-to-r from-secondary/5 to-primary/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="h-5 w-5" />
            Fitur Pengaturan yang Tersedia
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <h4 className="font-medium flex items-center gap-2">
                <HelpCircle className="h-4 w-4" />
                FAQ Interaktif
              </h4>
              <p className="text-sm text-muted-foreground">
                Sistem FAQ dengan pengaturan urutan dan validasi otomatis
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                Feedback Real-time
              </h4>
              <p className="text-sm text-muted-foreground">
                Form feedback dengan status baca dan notifikasi admin
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium flex items-center gap-2">
                <Users className="h-4 w-4" />
                Tim Management
              </h4>
              <p className="text-sm text-muted-foreground">
                Modul repeater untuk informasi tim dengan upload foto
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}