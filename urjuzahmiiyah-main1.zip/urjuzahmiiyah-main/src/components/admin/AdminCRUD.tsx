import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Plus, Edit, Trash2, Save, X, Search, Filter, Upload } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface CRUDProps {
  table: 'about_us' | 'admin_users' | 'categories' | 'events' | 'hijri_years' | 'faqs' | 'feedback' | 'hero_sections' | 'welcome_popup' | 'team_members' | 'downloads' | 'external_sources';
  title: string;
  fields: FieldConfig[];
}

interface FieldConfig {
  name: string;
  label: string;
  type: 'text' | 'textarea' | 'number' | 'boolean' | 'select' | 'image' | 'tags' | 'relation' | 'file';
  required?: boolean;
  options?: string[] | { value: string; label: string }[];
  table?: string;
}

export function AdminCRUD({ table, title, fields }: CRUDProps) {
  const [data, setData] = useState<any[]>([]);
  const [filteredData, setFilteredData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingItem, setEditingItem] = useState<any>(null);
  const [formData, setFormData] = useState<any>({});
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterActive, setFilterActive] = useState<boolean | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchData();
    
    // Setup real-time subscription
    const channel = supabase
      .channel(`${table}-changes`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: table
        },
        () => {
          fetchData(); // Refresh data when changes occur
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [table]);

  useEffect(() => {
    filterData();
  }, [data, searchTerm, filterActive]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const { data: result, error } = await supabase
        .from(table)
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setData(result || []);
    } catch (error) {
      toast({
        title: "Error",
        description: `Gagal memuat data ${title}`,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const filterData = () => {
    let filtered = [...data];

    if (searchTerm) {
      filtered = filtered.filter(item =>
        Object.values(item).some(value =>
          String(value).toLowerCase().includes(searchTerm.toLowerCase())
        )
      );
    }

    if (filterActive !== null) {
      filtered = filtered.filter(item => item.is_active === filterActive);
    }

    setFilteredData(filtered);
  };

  const resetForm = () => {
    const initialData: any = {};
    fields.forEach(field => {
      switch (field.type) {
        case 'boolean':
          initialData[field.name] = true;
          break;
        case 'number':
          initialData[field.name] = 0;
          break;
        default:
          initialData[field.name] = '';
      }
    });
    setFormData(initialData);
    setEditingItem(null);
  };

  const handleCreate = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  const handleEdit = (item: any) => {
    setEditingItem(item);
    setFormData({ ...item });
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    try {
      const requiredFields = fields.filter(f => f.required);
      const missingFields = requiredFields.filter(f => !formData[f.name]);
      
      if (missingFields.length > 0) {
        toast({
          title: "Error",
          description: `Field berikut wajib diisi: ${missingFields.map(f => f.label).join(', ')}`,
          variant: "destructive"
        });
        return;
      }

      if (editingItem) {
        const { error } = await supabase
          .from(table)
          .update(formData)
          .eq('id', editingItem.id);

        if (error) throw error;
        
        toast({
          title: "Berhasil",
          description: `${title} berhasil diperbarui`
        });
      } else {
        const { error } = await supabase
          .from(table)
          .insert([formData]);

        if (error) throw error;
        
        toast({
          title: "Berhasil",
          description: `${title} berhasil ditambahkan`
        });
      }

      setIsDialogOpen(false);
      fetchData();
      resetForm();
    } catch (error) {
      toast({
        title: "Error",
        description: `Gagal menyimpan ${title}`,
        variant: "destructive"
      });
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase
        .from(table)
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      toast({
        title: "Berhasil",
        description: `${title} berhasil dihapus`
      });
      
      fetchData();
    } catch (error) {
      toast({
        title: "Error",
        description: `Gagal menghapus ${title}`,
        variant: "destructive"
      });
    }
  };

  const renderField = (field: FieldConfig) => {
    const value = formData[field.name] || '';

    switch (field.type) {
      case 'textarea':
        return (
          <Textarea
            id={field.name}
            value={value}
            onChange={(e) => setFormData(prev => ({ ...prev, [field.name]: e.target.value }))}
            placeholder={`Masukkan ${field.label.toLowerCase()}`}
            className="min-h-[100px]"
          />
        );

      case 'number':
        return (
          <Input
            id={field.name}
            type="number"
            value={value}
            onChange={(e) => setFormData(prev => ({ ...prev, [field.name]: Number(e.target.value) }))}
            placeholder={`Masukkan ${field.label.toLowerCase()}`}
          />
        );

      case 'boolean':
        return (
          <Switch
            id={field.name}
            checked={value}
            onCheckedChange={(checked) => setFormData(prev => ({ ...prev, [field.name]: checked }))}
          />
        );

      case 'select':
        return (
          <Select
            value={value}
            onValueChange={(val) => setFormData(prev => ({ ...prev, [field.name]: val }))}
          >
            <SelectTrigger>
              <SelectValue placeholder={`Pilih ${field.label.toLowerCase()}`} />
            </SelectTrigger>
            <SelectContent>
              {field.options?.map(option => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );

      case 'image':
      case 'file':
        return (
          <div className="space-y-2">
            <Input
              id={field.name}
              type="url"
              value={value}
              onChange={(e) => setFormData(prev => ({ ...prev, [field.name]: e.target.value }))}
              placeholder={field.type === 'image' ? "https://example.com/image.jpg" : "URL file"}
            />
            <input
              type="file"
              accept={field.type === 'image' ? "image/*" : "*"}
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) {
                  // Validate file size (max 1MB for images, 10MB for files)
                  const maxSize = field.type === 'image' ? 1024 * 1024 : 10 * 1024 * 1024;
                  if (file.size > maxSize) {
                    alert(`File terlalu besar. Maksimal ${field.type === 'image' ? '1MB' : '10MB'}`);
                    return;
                  }
                  // Create blob URL for preview
                  const url = URL.createObjectURL(file);
                  setFormData(prev => ({ ...prev, [field.name]: url }));
                }
              }}
              className="hidden"
              id={`${field.name}-upload`}
            />
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => document.getElementById(`${field.name}-upload`)?.click()}
            >
              Upload {field.type === 'image' ? 'Gambar' : 'File'}
            </Button>
            {value && field.type === 'image' && (
              <div className="mt-2">
                <img 
                  src={value} 
                  alt="Preview" 
                  className="w-20 h-20 object-cover rounded border"
                />
              </div>
            )}
            {value && field.type === 'file' && (
              <div className="mt-2 text-sm text-muted-foreground">
                File: {value.split('/').pop()}
              </div>
            )}
          </div>
        );

      default:
        return (
          <Input
            id={field.name}
            type="text"
            value={value}
            onChange={(e) => setFormData(prev => ({ ...prev, [field.name]: e.target.value }))}
            placeholder={`Masukkan ${field.label.toLowerCase()}`}
          />
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <div>
          <h2 className="text-2xl font-bold text-foreground">{title}</h2>
          <p className="text-muted-foreground">Kelola data {title.toLowerCase()}</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={handleCreate}>
              <Plus className="h-4 w-4 mr-2" />
              Tambah {title}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingItem ? `Edit ${title}` : `Tambah ${title} Baru`}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              {fields.map((field) => (
                <div key={field.name} className="space-y-2">
                  <Label htmlFor={field.name} className="flex items-center gap-2">
                    {field.label}
                    {field.required && <span className="text-destructive">*</span>}
                  </Label>
                  {renderField(field)}
                </div>
              ))}
              <div className="flex justify-end gap-2 pt-4">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  <X className="h-4 w-4 mr-2" />
                  Batal
                </Button>
                <Button onClick={handleSave}>
                  <Save className="h-4 w-4 mr-2" />
                  Simpan
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Cari data..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select
              value={filterActive === null ? "all" : filterActive.toString()}
              onValueChange={(value) => setFilterActive(value === "all" ? null : value === "true")}
            >
              <SelectTrigger className="w-full sm:w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Status</SelectItem>
                <SelectItem value="true">Aktif</SelectItem>
                <SelectItem value="false">Tidak Aktif</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Data Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Data {title}</span>
            <Badge variant="secondary">{filteredData.length} item</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="text-muted-foreground mt-2">Memuat data...</p>
            </div>
          ) : filteredData.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    {fields.slice(0, 4).map((field) => (
                      <TableHead key={field.name}>{field.label}</TableHead>
                    ))}
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredData.map((item) => (
                    <TableRow key={item.id}>
                      {fields.slice(0, 4).map((field) => (
                        <TableCell key={field.name}>
                          {field.type === 'boolean' ? (
                            <Badge variant={item[field.name] ? "default" : "secondary"}>
                              {item[field.name] ? "Ya" : "Tidak"}
                            </Badge>
                          ) : field.type === 'image' && item[field.name] ? (
                            <img 
                              src={item[field.name]} 
                              alt="Preview" 
                              className="w-12 h-12 object-cover rounded-md"
                            />
                          ) : (
                            String(item[field.name] || '').substring(0, 50) + 
                            (String(item[field.name] || '').length > 50 ? '...' : '')
                          )}
                        </TableCell>
                      ))}
                      <TableCell>
                        <Badge variant={item.is_active ? "default" : "secondary"}>
                          {item.is_active ? "Aktif" : "Tidak Aktif"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEdit(item)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="outline" size="sm">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Hapus {title}?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Tindakan ini tidak dapat dibatalkan. Data akan dihapus permanen.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Batal</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDelete(item.id)}>
                                  Hapus
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Tidak ada data {title.toLowerCase()}</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}