import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Save, 
  Edit3, 
  Eye, 
  EyeOff, 
  Home, 
  Info, 
  Calendar,
  MessageSquare,
  RefreshCw,
  Check,
  X,
  Clock,
  Grid3X3,
  MapPin,
  Download,
  Settings,
  Upload,
  Image as ImageIcon
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { HomepageManager } from "./HomepageManager";
import { TimelineManager } from "./TimelineManager";
import { DownloadManager } from "./DownloadManager";
import { SettingsManager } from "./SettingsManager";

interface ContentSection {
  id: string;
  section_key: string;
  title: string;
  description: string;
  content: any;
  is_active: boolean;
  updated_at: string;
}

export function ContentManager() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Panel Admin Urjuzah Miiyah</h2>
          <p className="text-muted-foreground">Kelola seluruh konten website dengan mudah</p>
        </div>
      </div>

      <Tabs defaultValue="homepage" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="homepage" className="flex items-center gap-2">
            <Home className="h-4 w-4" />
            Homepage
          </TabsTrigger>
          <TabsTrigger value="timeline" className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            Timeline
          </TabsTrigger>
          <TabsTrigger value="download" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Download
          </TabsTrigger>
        </TabsList>

        <TabsContent value="homepage">
          <HomepageManager />
        </TabsContent>

        <TabsContent value="timeline">
          <TimelineManager />
        </TabsContent>

        <TabsContent value="download">
          <DownloadManager />
        </TabsContent>
      </Tabs>
    </div>
  );
}