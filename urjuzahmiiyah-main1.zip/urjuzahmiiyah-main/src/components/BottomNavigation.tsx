import { motion } from "framer-motion";
import { Home, Calendar, Download, Settings, HelpCircle, Users } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";

const navItems = [
  { icon: Home, label: "Home", path: "/" },
  { icon: Users, label: "Fase", path: "/fase" },
  { icon: Calendar, label: "Timeline", path: "/timeline" },
  { icon: Download, label: "Download", path: "/download" },
  { icon: Settings, label: "Setting", path: "/settings" },
];

export function BottomNavigation() {
  const location = useLocation();
  const navigate = useNavigate();
  
  // Don't show on admin pages
  if (location.pathname.startsWith('/admin') || location.pathname.startsWith('/auth')) {
    return null;
  }

  return (
    <motion.div
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      className="fixed bottom-0 left-0 right-0 z-50 bg-card/95 backdrop-blur-md border-t border-border"
    >
      <div className="flex items-center justify-center px-2 py-2 w-full max-w-md mx-auto">
        <div className="flex items-center justify-around w-full px-4">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <motion.button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={cn(
                "flex flex-col items-center justify-center px-3 py-2 rounded-xl transition-all duration-200",
                isActive
                  ? "bg-primary text-primary-foreground shadow-lg"
                  : "text-muted-foreground hover:text-foreground hover:bg-accent"
              )}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <item.icon className="h-5 w-5 mb-1" />
              <span className="text-xs font-medium">{item.label}</span>
            </motion.button>
          );
        })}
        </div>
      </div>
    </motion.div>
  );
}