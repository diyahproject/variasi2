import { useState, useEffect } from "react";

const HeroSection = () => {
  const [currentImage] = useState<string>(
    "/lovable-uploads/0678fc7f-476f-4e22-94ac-6b676f3a33f3.png"
  );

  useEffect(() => {
    // Add CSS to document head
    const style = document.createElement('style');
    style.textContent = `
      .hero-section-custom {
        background: radial-gradient(ellipse at center, #4a6b5a 0%, #3a5a4a 50%, #2a4a3a 100%);
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        position: relative;
        overflow: hidden;
      }

      .hero-section-custom::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: 
          radial-gradient(circle at 20% 30%, rgba(212, 175, 55, 0.15) 0%, transparent 50%),
          radial-gradient(circle at 80% 20%, rgba(255, 235, 59, 0.1) 0%, transparent 60%),
          radial-gradient(circle at 60% 80%, rgba(212, 175, 55, 0.12) 0%, transparent 40%),
          radial-gradient(circle at 10% 70%, rgba(255, 193, 7, 0.08) 0%, transparent 50%);
        animation: gentleGlow 8s ease-in-out infinite alternate;
        pointer-events: none;
      }

      @keyframes gentleGlow {
        0% {
          opacity: 0.3;
          transform: scale(1) rotate(0deg);
        }
        50% {
          opacity: 0.6;
          transform: scale(1.05) rotate(2deg);
        }
        100% {
          opacity: 0.4;
          transform: scale(1.02) rotate(-1deg);
        }
      }

      .floating-lights {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        pointer-events: none;
        overflow: hidden;
      }

      .light-particle {
        position: absolute;
        width: 4px;
        height: 4px;
        background: #d4af37;
        border-radius: 50%;
        box-shadow: 0 0 10px #d4af37, 0 0 20px #d4af37, 0 0 30px #d4af37;
        animation: floatUp 15s linear infinite;
        opacity: 0;
      }

      .light-particle:nth-child(odd) {
        background: #ffeb3b;
        box-shadow: 0 0 8px #ffeb3b, 0 0 16px #ffeb3b, 0 0 24px #ffeb3b;
      }

      .light-particle:nth-child(1) { left: 10%; animation-delay: 0s; animation-duration: 12s; }
      .light-particle:nth-child(2) { left: 20%; animation-delay: 2s; animation-duration: 15s; }
      .light-particle:nth-child(3) { left: 30%; animation-delay: 4s; animation-duration: 13s; }
      .light-particle:nth-child(4) { left: 40%; animation-delay: 1s; animation-duration: 16s; }
      .light-particle:nth-child(5) { left: 50%; animation-delay: 3s; animation-duration: 14s; }
      .light-particle:nth-child(6) { left: 60%; animation-delay: 5s; animation-duration: 12s; }
      .light-particle:nth-child(7) { left: 70%; animation-delay: 2.5s; animation-duration: 17s; }
      .light-particle:nth-child(8) { left: 80%; animation-delay: 4.5s; animation-duration: 11s; }
      .light-particle:nth-child(9) { left: 90%; animation-delay: 1.5s; animation-duration: 18s; }

      @keyframes floatUp {
        0% {
          bottom: -10px;
          opacity: 0;
          transform: translateX(0px) scale(0.5);
        }
        10% {
          opacity: 1;
          transform: translateX(10px) scale(1);
        }
        50% {
          opacity: 0.8;
          transform: translateX(-20px) scale(0.8);
        }
        90% {
          opacity: 0.3;
          transform: translateX(30px) scale(0.6);
        }
        100% {
          bottom: 100vh;
          opacity: 0;
          transform: translateX(-10px) scale(0.3);
        }
      }

      .ambient-glow {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 800px;
        height: 800px;
        transform: translate(-50%, -50%);
        background: radial-gradient(circle, rgba(212, 175, 55, 0.05) 0%, transparent 70%);
        animation: ambientPulse 6s ease-in-out infinite;
        pointer-events: none;
      }

      @keyframes ambientPulse {
        0%, 100% {
          transform: translate(-50%, -50%) scale(0.8);
          opacity: 0.3;
        }
        50% {
          transform: translate(-50%, -50%) scale(1.2);
          opacity: 0.1;
        }
      }

      .hero-container {
        max-width: 1200px;
        width: 100%;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 60px;
        align-items: center;
        position: relative;
        z-index: 2;
      }

      .hero-content {
        color: white;
        z-index: 2;
        position: relative;
      }

      .hero-content h1 {
        font-size: 3.5rem;
        font-weight: 300;
        line-height: 1.2;
        margin-bottom: 20px;
        letter-spacing: -0.02em;
        text-shadow: 0 0 20px rgba(212, 175, 55, 0.3);
        animation: textGlow 4s ease-in-out infinite alternate;
      }

      .hero-content h1 strong {
        font-weight: 600;
        color: #d4af37;
        text-shadow: 
          0 0 10px rgba(212, 175, 55, 0.6),
          0 0 20px rgba(212, 175, 55, 0.4),
          0 0 30px rgba(212, 175, 55, 0.2);
        animation: strongTextGlow 3s ease-in-out infinite alternate;
      }

      @keyframes textGlow {
        0% {
          text-shadow: 0 0 20px rgba(212, 175, 55, 0.3);
        }
        100% {
          text-shadow: 0 0 30px rgba(212, 175, 55, 0.5), 0 0 40px rgba(255, 235, 59, 0.2);
        }
      }

      @keyframes strongTextGlow {
        0% {
          text-shadow: 
            0 0 10px rgba(212, 175, 55, 0.6),
            0 0 20px rgba(212, 175, 55, 0.4),
            0 0 30px rgba(212, 175, 55, 0.2);
        }
        100% {
          text-shadow: 
            0 0 15px rgba(212, 175, 55, 0.8),
            0 0 30px rgba(212, 175, 55, 0.6),
            0 0 45px rgba(212, 175, 55, 0.4),
            0 0 60px rgba(255, 235, 59, 0.2);
        }
      }

      .hero-subtitle {
        font-size: 1.2rem;
        color: rgba(255, 255, 255, 0.85);
        margin-bottom: 30px;
        line-height: 1.4;
        font-weight: 300;
        text-shadow: 0 0 15px rgba(255, 255, 255, 0.1);
      }

      .cta-button {
        background: linear-gradient(135deg, #d4af37, #b8941f);
        color: white;
        border: 2px solid rgba(212, 175, 55, 0.8);
        padding: 15px 35px;
        border-radius: 8px;
        font-size: 16px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.3s ease;
        text-decoration: none;
        display: inline-block;
        box-shadow: 
          0 4px 15px rgba(212, 175, 55, 0.3),
          0 0 20px rgba(212, 175, 55, 0.2);
        position: relative;
        overflow: hidden;
        animation: buttonGlow 3s ease-in-out infinite alternate;
      }

      @keyframes buttonGlow {
        0% {
          box-shadow: 
            0 4px 15px rgba(212, 175, 55, 0.3),
            0 0 20px rgba(212, 175, 55, 0.2);
        }
        100% {
          box-shadow: 
            0 6px 25px rgba(212, 175, 55, 0.5),
            0 0 35px rgba(212, 175, 55, 0.3);
        }
      }

      .cta-button::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
        transition: left 0.5s;
      }

      .cta-button:hover::before {
        left: 100%;
      }

      .cta-button:hover {
        background: linear-gradient(135deg, #e6c659, #d4af37);
        border-color: rgba(230, 198, 89, 1);
        transform: translateY(-2px);
        box-shadow: 
          0 8px 25px rgba(212, 175, 55, 0.4),
          0 0 40px rgba(212, 175, 55, 0.3);
      }

      .hero-image-container {
        display: flex;
        justify-content: center;
        align-items: center;
        position: relative;
      }

      .image-frame {
        position: relative;
        width: 516px;
        height: 669px;
        background: 
          linear-gradient(145deg, #c5beb2, #ede6da),
          repeating-linear-gradient(
            90deg,
            #D9D2C6 0px,
            #d1cab0 2px,
            #e5ddc8 4px,
            #cfc8ac 6px,
            #D9D2C6 8px
          );
        border-radius: 258px 258px 12px 12px;
        padding: 37px;
        box-shadow: 
          0 37px 75px rgba(0, 0, 0, 0.3),
          0 18px 37px rgba(0, 0, 0, 0.2),
          inset 0 3px 6px rgba(255, 255, 255, 0.4),
          inset 0 -3px 6px rgba(0, 0, 0, 0.1),
          inset 3px 0 6px rgba(255, 255, 255, 0.3),
          inset -3px 0 6px rgba(0, 0, 0, 0.1),
          0 7px 22px rgba(0, 0, 0, 0.15),
          0 3px 12px rgba(0, 0, 0, 0.1),
          0 0 30px rgba(212, 175, 55, 0.1);
        border: 4px solid #c9c2b6;
        transform: perspective(1500px) rotateX(2deg) rotateY(-2deg);
        transition: all 0.3s ease;
        overflow: hidden;
        animation: frameGlow 5s ease-in-out infinite alternate;
      }

      @keyframes frameGlow {
        0% {
          box-shadow: 
            0 37px 75px rgba(0, 0, 0, 0.3),
            0 18px 37px rgba(0, 0, 0, 0.2),
            inset 0 3px 6px rgba(255, 255, 255, 0.4),
            inset 0 -3px 6px rgba(0, 0, 0, 0.1),
            inset 3px 0 6px rgba(255, 255, 255, 0.3),
            inset -3px 0 6px rgba(0, 0, 0, 0.1),
            0 7px 22px rgba(0, 0, 0, 0.15),
            0 3px 12px rgba(0, 0, 0, 0.1),
            0 0 30px rgba(212, 175, 55, 0.1);
        }
        100% {
          box-shadow: 
            0 37px 75px rgba(0, 0, 0, 0.3),
            0 18px 37px rgba(0, 0, 0, 0.2),
            inset 0 3px 6px rgba(255, 255, 255, 0.4),
            inset 0 -3px 6px rgba(0, 0, 0, 0.1),
            inset 3px 0 6px rgba(255, 255, 255, 0.3),
            inset -3px 0 6px rgba(0, 0, 0, 0.1),
            0 7px 22px rgba(0, 0, 0, 0.15),
            0 3px 12px rgba(0, 0, 0, 0.1),
            0 0 50px rgba(212, 175, 55, 0.2),
            0 0 80px rgba(255, 235, 59, 0.1);
        }
      }

      .image-frame::before {
        content: '';
        position: absolute;
        top: -10px;
        left: -10px;
        right: -10px;
        bottom: -10px;
        background: conic-gradient(
          transparent,
          rgba(212, 175, 55, 0.3),
          transparent,
          rgba(255, 235, 59, 0.2),
          transparent,
          rgba(212, 175, 55, 0.3),
          transparent
        );
        border-radius: 268px 268px 22px 22px;
        animation: rotateRing 8s linear infinite;
        pointer-events: none;
        opacity: 0.7;
      }

      @keyframes rotateRing {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }

      .image-frame::after {
        content: '';
        position: absolute;
        top: 22px;
        left: 22px;
        right: 22px;
        bottom: 22px;
        border: 3px solid rgba(139, 126, 102, 0.3);
        border-radius: 236px 236px 6px 6px;
        box-shadow: 
          inset 0 1px 3px rgba(255, 255, 255, 0.3),
          inset 0 -1px 3px rgba(0, 0, 0, 0.1);
        pointer-events: none;
        z-index: 1;
      }

      .image-frame:hover {
        transform: perspective(1500px) rotateX(0deg) rotateY(0deg) scale(1.02);
        animation-play-state: paused;
      }

      .hero-image {
        width: 100%;
        height: 100%;
        object-fit: contain;
        border-radius: 221px 221px 6px 6px;
        transition: all 0.3s ease;
        position: relative;
        z-index: 2;
        box-shadow: 
          0 6px 22px rgba(0, 0, 0, 0.2),
          0 0 20px rgba(212, 175, 55, 0.05);
      }

      .hero-image:hover {
        transform: scale(1.02);
        box-shadow: 
          0 6px 22px rgba(0, 0, 0, 0.2),
          0 0 30px rgba(212, 175, 55, 0.1);
      }

      @media (max-width: 768px) {
        .hero-container {
          grid-template-columns: 1fr;
          gap: 40px;
          text-align: center;
        }
        .hero-content { order: 2; }
        .hero-image-container { order: 1; }
        .hero-content h1 { font-size: 2.5rem; margin-bottom: 25px; }
        .image-frame {
          width: 290px;
          height: 376px;
          border-radius: 145px 145px 6px 6px;
          padding: 20px;
        }
        .image-frame::before { border-radius: 155px 155px 16px 16px; }
        .image-frame::after {
          top: 15px; left: 15px; right: 15px; bottom: 15px;
          border: 2px solid rgba(139, 126, 102, 0.3);
          border-radius: 130px 130px 3px 3px;
        }
        .hero-image { border-radius: 125px 125px 3px 3px; }
      }

      @media (max-width: 480px) {
        .hero-content h1 { font-size: 2rem; }
        .image-frame {
          width: 240px;
          height: 312px;
          border-radius: 120px 120px 5px 5px;
          padding: 15px;
        }
        .image-frame::before { border-radius: 130px 130px 15px 15px; }
        .image-frame::after {
          top: 12px; left: 12px; right: 12px; bottom: 12px;
          border-radius: 108px 108px 2px 2px;
        }
        .hero-image { border-radius: 105px 105px 2px 2px; }
        .cta-button { padding: 12px 28px; font-size: 14px; }
      }
    `;
    document.head.appendChild(style);

    return () => {
      document.head.removeChild(style);
    };
  }, []);

  return (
    <section className="hero-section-custom">
      {/* Ambient Glow Background */}
      <div className="ambient-glow"></div>
      
      {/* Floating Light Particles */}
      <div className="floating-lights">
        <div className="light-particle"></div>
        <div className="light-particle"></div>
        <div className="light-particle"></div>
        <div className="light-particle"></div>
        <div className="light-particle"></div>
        <div className="light-particle"></div>
        <div className="light-particle"></div>
        <div className="light-particle"></div>
        <div className="light-particle"></div>
      </div>

      <div className="hero-container">
        <div className="hero-content">
          <h1>Jelajahi <strong>Khazanah Peradaban Islam</strong> yang Mulia</h1>
          <p className="hero-subtitle">Temukan warisan intelektual, spiritual, dan budaya yang telah membentuk peradaban dunia selama lebih dari 14 abad</p>
          <a href="#" className="cta-button">Mulai Penjelajahan ✨</a>
        </div>
        
        <div className="hero-image-container">
          <div className="image-frame">
            <img className="hero-image" src={currentImage} alt="Khazanah Peradaban Islam" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;