import { useState } from "react";
import { motion } from "framer-motion";
import { Search, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { RotatingText } from "@/components/RotatingText";
interface SearchBarProps {
  onSearch?: (query: string) => void;
  placeholder?: string;
}
export function SearchBar({
  onSearch,
  placeholder = "Cari tokoh, peristiwa, atau tahun..."
}: SearchBarProps) {
  const [query, setQuery] = useState("");
  const [isFocused, setIsFocused] = useState(false);
  const handleSearch = () => {
    if (query.trim() && onSearch) {
      onSearch(query.trim());
    }
  };
  const handleClear = () => {
    setQuery("");
    if (onSearch) {
      onSearch("");
    }
  };
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };
  const rotatingTexts = ["peristiwa bersejarah", "tokoh legendaris", "momen penting", "warisan budaya", "jejak peradaban"];
  return <motion.div initial={{
    opacity: 0,
    y: 20
  }} animate={{
    opacity: 1,
    y: 0
  }} transition={{
    duration: 0.5
  }} className="mb-8 space-y-6">
      {/* Rotating text above search bar */}
      <motion.div initial={{
      opacity: 0,
      y: 10
    }} animate={{
      opacity: 1,
      y: 0
    }} transition={{
      delay: 0.3,
      duration: 0.6
    }} className="text-center">
        
      </motion.div>

      <Card className={`p-4 transition-all duration-300 ${isFocused ? 'ring-2 ring-primary/50 shadow-lg' : ''}`}>
        <div className="flex items-center gap-3">
          <Search className="h-5 w-5 text-muted-foreground flex-shrink-0" />
          
          <Input value={query} onChange={e => setQuery(e.target.value)} onFocus={() => setIsFocused(true)} onBlur={() => setIsFocused(false)} onKeyPress={handleKeyPress} placeholder={placeholder} className="border-0 bg-transparent p-0 text-lg focus-visible:ring-0 focus-visible:ring-offset-0" />

          {query && <motion.div initial={{
          scale: 0
        }} animate={{
          scale: 1
        }} exit={{
          scale: 0
        }}>
              <Button variant="ghost" size="icon" onClick={handleClear} className="h-8 w-8 text-muted-foreground hover:text-foreground">
                <X className="h-4 w-4" />
              </Button>
            </motion.div>}

          <Button onClick={handleSearch} disabled={!query.trim()} className="bg-primary hover:bg-primary/90 text-primary-foreground">
            Cari
          </Button>
        </div>
      </Card>
    </motion.div>;
}