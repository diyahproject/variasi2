import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Grid3X3, ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
interface Category {
  id: string;
  name: string;
  description: string;
  image_url: string;
  badge_text: string;
}
export function CategoriesSection() {
  const [categories, setCategories] = useState<Category[]>([]);
  const navigate = useNavigate();
  
  useEffect(() => {
    const fetchCategories = async () => {
      const { data } = await supabase.from('categories').select('*').eq('is_active', true).order('sort_order');
      if (data) {
        setCategories(data);
      }
    };
    fetchCategories();

    // Real-time subscription
    const subscription = supabase.channel('categories_changes').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'categories'
    }, () => fetchCategories()).subscribe();
    
    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const handleCategoryClick = (categoryId: string) => {
    navigate(`/category/${categoryId}`);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      transition={{ duration: 0.6 }} 
      className="mb-12"
    >
      <div className="flex items-center gap-3 mb-6">
        <Grid3X3 className="h-6 w-6 text-primary" />
        <h2 className="text-2xl font-bold text-primary">Kategori Sejarah</h2>
      </div>

      <div className="flex justify-center items-center p-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-6xl">
          {categories.map((category, index) => (
            <motion.div 
              key={category.id} 
              initial={{ opacity: 0, y: 20 }} 
              animate={{ opacity: 1, y: 0 }} 
              transition={{ delay: index * 0.1, duration: 0.5 }}
            >
              <div 
                className="bg-white rounded-3xl shadow-lg overflow-hidden cursor-pointer transition-all duration-300 hover:shadow-xl hover:scale-[1.02] h-full flex flex-col" 
                onClick={() => handleCategoryClick(category.id)}
              >
                <div className="p-4 flex-1">
                  <div className="relative rounded-2xl overflow-hidden h-48">
                    <img
                      src={category.image_url || 'https://placehold.co/600x400/E0E0E0/FFFFFF?text=Gambar+tidak+tersedia'}
                      alt={category.name}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.currentTarget.onerror = null;
                        e.currentTarget.src = "https://placehold.co/600x400/E0E0E0/FFFFFF?text=Gambar+tidak+tersedia";
                      }}
                    />
                    {category.badge_text && (
                      <div className="absolute top-4 left-4 bg-gray-700 bg-opacity-70 text-white text-sm px-4 py-2 rounded-full font-semibold">
                        {category.badge_text.includes('610') ? 'Tahun 610 - 662 M' : 
                         category.badge_text.includes('622') ? 'Tahun 622 - 632 M' : 
                         category.badge_text.includes('632') ? 'Tahun 632 - 661 M' : 
                         category.badge_text}
                      </div>
                    )}
                  </div>
                </div>
                <div className="pt-[2px] pb-3.5 px-6 rounded-b-3xl flex-shrink-0">
                  <h2 className="text-2xl font-semibold text-gray-800">{category.name}</h2>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}