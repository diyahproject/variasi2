import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";

export function WelcomePopup() {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    setIsOpen(true);
  }, []);

  const handleClose = () => {
    setIsOpen(false);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="w-[95vw] h-[95vh] max-w-none bg-transparent border-none shadow-none p-0 overflow-hidden">
          <DialogTitle className="sr-only">Sholawat dan Sambutan</DialogTitle>
          
          {/* Background with Glassmorphism */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0, rotateY: -90 }}
            animate={{ scale: 1, opacity: 1, rotateY: 0 }}
            exit={{ scale: 0.8, opacity: 0, rotateY: 90 }}
            transition={{ 
              duration: 1.2, 
              ease: [0.25, 0.46, 0.45, 0.94],
              type: "spring",
              stiffness: 100
            }}
            className="relative h-full w-full backdrop-blur-2xl bg-gradient-to-br from-background/20 via-primary/10 to-secondary/20 rounded-3xl border border-white/20 shadow-2xl overflow-hidden"
          >
            {/* Animated Islamic Geometric Patterns */}
            <div className="absolute inset-0 opacity-20">
              {[...Array(8)].map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute w-32 h-32 border border-primary/30 rounded-full"
                  style={{
                    top: `${Math.random() * 100}%`,
                    left: `${Math.random() * 100}%`,
                  }}
                  animate={{
                    scale: [1, 1.5, 1],
                    opacity: [0.3, 0.6, 0.3],
                    rotate: [0, 360],
                  }}
                  transition={{
                    duration: 8 + i * 2,
                    repeat: Infinity,
                    delay: i * 0.5,
                  }}
                />
              ))}
            </div>

            {/* Floating Particles */}
            <div className="absolute inset-0">
              {[...Array(20)].map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute w-2 h-2 bg-primary/40 rounded-full"
                  style={{
                    top: `${Math.random() * 100}%`,
                    left: `${Math.random() * 100}%`,
                  }}
                  animate={{
                    y: [-20, -100],
                    opacity: [0, 1, 0],
                  }}
                  transition={{
                    duration: 3 + Math.random() * 2,
                    repeat: Infinity,
                    delay: Math.random() * 2,
                  }}
                />
              ))}
            </div>

            {/* Close Button */}
            <motion.div
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5 }}
              className="absolute right-6 top-6 z-20"
            >
              <Button
                variant="ghost"
                size="icon"
                className="h-12 w-12 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/30 transition-all duration-300 hover:scale-110"
                onClick={handleClose}
              >
                <X className="h-6 w-6 text-foreground" />
              </Button>
            </motion.div>

            {/* Main Content */}
            <div className="flex flex-col h-full items-center justify-center p-8 text-center relative z-10">
              
              {/* Animated Islamic Calligraphy Container */}
              <motion.div
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3, duration: 0.8 }}
                className="relative mb-8"
              >
                {/* Glowing Background */}
                <motion.div
                  animate={{
                    scale: [1, 1.1, 1],
                    opacity: [0.5, 0.8, 0.5],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                  }}
                  className="absolute inset-0 bg-gradient-to-r from-primary/30 via-secondary/30 to-accent/30 rounded-full blur-3xl"
                />
                
                {/* Main Islamic Art */}
                <div className="relative w-48 h-48 flex items-center justify-center">
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                    className="absolute inset-0 border-2 border-primary/30 rounded-full"
                  />
                  <motion.div
                    animate={{ rotate: -360 }}
                    transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
                    className="absolute inset-4 border border-secondary/40 rounded-full"
                  />
                  <div className="text-6xl">🕌</div>
                </div>
              </motion.div>

              {/* Welcome Text */}
              <motion.div
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.6, duration: 0.8 }}
                className="space-y-6 max-w-2xl"
              >
                {/* Greeting */}
                <motion.h2
                  animate={{ 
                    textShadow: [
                      "0 0 20px hsl(var(--primary))",
                      "0 0 40px hsl(var(--primary))",
                      "0 0 20px hsl(var(--primary))"
                    ]
                  }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="text-3xl sm:text-4xl font-bold text-foreground mb-6"
                >
                  بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ
                </motion.h2>

                {/* Complete Sholawat in Beautiful Glassmorphism Container */}
                <motion.div
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.9, duration: 0.6 }}
                  className="backdrop-blur-xl bg-white/10 p-8 rounded-3xl border border-white/20 shadow-2xl"
                >
                  <div className="space-y-4">
                    {/* Main Sholawat */}
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 1.2, duration: 1 }}
                      className="text-center"
                    >
                      <p className="text-2xl sm:text-3xl font-bold text-foreground leading-relaxed mb-4" dir="rtl">
                        اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ عَلَى سَيِّدِنَا مُحَمَّدٍ
                      </p>
                      <p className="text-xl sm:text-2xl text-foreground/90 leading-relaxed" dir="rtl">
                        وَعَلَى آلِ سَيِّدِنَا مُحَمَّدٍ فِي كُلِّ لَمْحَةٍ وَنَفَسٍ
                      </p>
                      <p className="text-xl sm:text-2xl text-foreground/90 leading-relaxed mt-2" dir="rtl">
                        بِعَدَدِ كُلِّ مَعْلُومٍ لَكَ
                      </p>
                    </motion.div>

                    {/* Translation */}
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 1.5, duration: 0.8 }}
                      className="bg-gradient-to-r from-primary/20 to-secondary/20 backdrop-blur-sm p-4 rounded-2xl border border-white/10"
                    >
                      <p className="text-sm sm:text-base text-foreground/80 italic">
                        "Ya Allah, limpahkanlah sholawat, salam dan berkah kepada junjungan kami Nabi Muhammad dan kepada keluarga Nabi Muhammad di setiap saat dan nafas, sebanyak segala yang Engkau ketahui"
                      </p>
                    </motion.div>
                  </div>
                </motion.div>

                {/* Additional Welcome Message */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1.8, duration: 0.6 }}
                  className="backdrop-blur-xl bg-white/5 p-6 rounded-2xl border border-white/10"
                >
                  <p className="text-foreground/90 text-lg leading-relaxed">
                    Selamat datang di perjalanan spiritual menuju jejak-jejak Rasulullah ﷺ. 
                    Mari kita telusuri kisah suci yang penuh hikmah dan berkah
                  </p>
                </motion.div>

                {/* Enter Button */}
                <motion.div
                  initial={{ y: 30, opacity: 0, scale: 0.8 }}
                  animate={{ y: 0, opacity: 1, scale: 1 }}
                  transition={{ delay: 2.1, duration: 0.8, type: "spring" }}
                  className="pt-4"
                >
                  <Button
                    onClick={handleClose}
                    className="group relative px-12 py-6 text-xl font-bold bg-gradient-to-r from-primary via-secondary to-accent hover:from-primary/80 hover:via-secondary/80 hover:to-accent/80 text-primary-foreground shadow-2xl rounded-full border-2 border-white/20 transition-all duration-500 hover:scale-110 hover:shadow-3xl overflow-hidden"
                    size="lg"
                  >
                    <span className="relative z-10">بِسْمِ اللَّهِ نَبْدَأُ ✨</span>
                    
                    {/* Animated Background */}
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-primary/20 to-secondary/20"
                      animate={{
                        x: ["-100%", "100%"],
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        ease: "linear",
                      }}
                    />
                  </Button>
                </motion.div>

                {/* Decorative Elements */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 2.4, duration: 0.6 }}
                  className="flex justify-center space-x-4 pt-4"
                >
                  {[...Array(5)].map((_, i) => (
                    <motion.div
                      key={i}
                      animate={{ 
                        scale: [1, 1.3, 1],
                        opacity: [0.5, 1, 0.5],
                      }}
                      transition={{ 
                        repeat: Infinity, 
                        duration: 2, 
                        delay: i * 0.2 
                      }}
                      className="w-3 h-3 bg-gradient-to-r from-primary to-secondary rounded-full shadow-lg"
                    />
                  ))}
                </motion.div>
              </motion.div>
            </div>
          </motion.div>
        </DialogContent>
      </Dialog>
    </AnimatePresence>
  );
}