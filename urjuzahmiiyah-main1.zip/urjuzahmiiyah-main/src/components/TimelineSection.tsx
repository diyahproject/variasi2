import React, { useState, useEffect, useRef } from 'react';

export function TimelineSection() {
  const images = [
    { src: 'https://placehold.co/400x600/22c55e/ffffff', alt: 'Green matrix code' },
    { src: 'https://placehold.co/400x600/0f766e/ffffff', alt: 'Blue code on screen' },
    { src: 'https://placehold.co/400x600/10b981/ffffff', alt: 'Woman working on computer' },
    { src: 'https://placehold.co/400x600/065f46/ffffff', alt: 'Abstract blue light' },
    { src: 'https://placehold.co/400x600/059669/ffffff', alt: 'Building domes' },
    { src: 'https://placehold.co/400x600/047857/ffffff', alt: 'Building domes' },
  ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const carouselRef = useRef<HTMLDivElement>(null);

  const goToNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
  };

  const goToPrevious = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + images.length) % images.length);
  };

  const handleDotClick = (index: number) => {
    setCurrentIndex(index);
  };

  // Auto-scroll functionality
  useEffect(() => {
    const interval = setInterval(() => {
      goToNext();
    }, 5000); // Change image every 5 seconds
    return () => clearInterval(interval);
  }, [currentIndex]);

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'ArrowRight') {
        goToNext();
      } else if (event.key === 'ArrowLeft') {
        goToPrevious();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Calculate transform for carousel items
  const getTransformValue = () => {
    const itemWidth = 200 + 16; // Card width + margin-right
    const offset = (carouselRef.current ? carouselRef.current.offsetWidth / 2 : 0) - (itemWidth / 2);
    return `translateX(${-(currentIndex * itemWidth) + offset}px)`;
  };

  return (
    <div className="mb-12">
      <div className="min-h-screen flex items-center justify-center p-4 font-sans relative bg-gray-100">
        <div className="w-full max-w-6xl bg-white rounded-xl shadow-lg p-6 md:p-8 relative z-10">
          {/* Header Section */}
          <div className="flex items-center mb-6">
            <svg className="w-8 h-8 mr-3" fill="#406251" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
            </svg>
            <h2 className="text-2xl font-bold text-gray-800">Timeline Hijriyah</h2>
          </div>

          {/* Carousel Container */}
          <div className="relative overflow-hidden group">
            <div
              ref={carouselRef}
              className="flex transition-transform duration-500 ease-in-out py-4"
              style={{ transform: getTransformValue() }}
            >
              {images.map((image, index) => (
                <div
                  key={index}
                  className={`flex-shrink-0 w-48 h-72 md:w-56 md:h-80 mx-2 rounded-xl overflow-hidden shadow-md transition-all duration-300 ease-in-out relative
                    ${index === currentIndex ? 'scale-105 ring-4 ring-opacity-75' : 'scale-90 opacity-70'}`}
                  style={index === currentIndex ? { '--tw-ring-color': '#406251' } as React.CSSProperties : {}}
                >
                  <img
                    src={image.src}
                    alt={image.alt}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).onerror = null;
                      (e.target as HTMLImageElement).src = `https://placehold.co/400x600/6b7280/ffffff?text=Image`;
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-70"></div>
                </div>
              ))}
            </div>

            {/* Navigation Buttons */}
            <button
              onClick={goToPrevious}
              className="absolute left-0 top-1/2 -translate-y-1/2 bg-white bg-opacity-75 hover:bg-opacity-100 rounded-full p-2 shadow-lg transition-all duration-300 ease-in-out
                       focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-75 opacity-0 group-hover:opacity-100"
              aria-label="Previous slide"
            >
              <svg className="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7"></path>
              </svg>
            </button>
            <button
              onClick={goToNext}
              className="absolute right-0 top-1/2 -translate-y-1/2 bg-white bg-opacity-75 hover:bg-opacity-100 rounded-full p-2 shadow-lg transition-all duration-300 ease-in-out
                       focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-75 opacity-0 group-hover:opacity-100"
              aria-label="Next slide"
            >
              <svg className="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path>
              </svg>
            </button>
          </div>

          {/* Dots Indicator */}
          <div className="flex justify-center mt-6 space-x-2">
            {images.map((_, index) => (
              <button
                key={index}
                onClick={() => handleDotClick(index)}
                className={`w-3 h-3 rounded-full transition-all duration-300 ease-in-out
                  ${index === currentIndex ? 'w-4 h-4' : 'bg-gray-300 hover:bg-gray-400'}`}
                style={index === currentIndex ? { backgroundColor: '#406251' } : {}}
                aria-label={`Go to slide ${index + 1}`}
              ></button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}