import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Navigation, Calendar, BookOpen, Download, Settings } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
const HeaderLetters = ({
  text,
  className = ""
}: {
  text: string;
  className?: string;
}) => {
  return <span className={className}>
      {text.split("").map((letter, index) => <motion.span key={index} initial={{
      opacity: 0,
      y: 20
    }} animate={{
      opacity: 1,
      y: 0
    }} transition={{
      delay: index * 0.1,
      duration: 0.6,
      ease: "easeOut"
    }} whileHover={{
      scale: 1.2,
      color: "hsl(var(--primary))",
      transition: {
        duration: 0.2
      }
    }} className="inline-block cursor-default transition-colors duration-200" style={{
      letterSpacing: letter === " " ? "0.5em" : "0.1em"
    }}>
          {letter === " " ? "\u00A0" : letter}
        </motion.span>)}
    </span>;
};
export function AnimatedHeader() {
  const [isScrolled, setIsScrolled] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
  const navigationItems = [{
    icon: BookOpen,
    label: "Beranda",
    path: "/"
  }, {
    icon: Calendar,
    label: "Timeline",
    path: "/timeline"
  }, {
    icon: Download,
    label: "Download",
    path: "/download"
  }, {
    icon: Settings,
    label: "Settings",
    path: "/settings"
  }];
  return <motion.header initial={{
    opacity: 0,
    y: -100
  }} animate={{
    opacity: 1,
    y: 0
  }} transition={{
    duration: 0.8,
    ease: "easeOut"
  }} className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${isScrolled ? "bg-background/95 backdrop-blur-lg border-b border-border/50 shadow-lg" : "bg-transparent"}`}>
      <div className="container mx-auto px-60 gap-y-48 rounded-sm">
        

        {/* Animated Border */}
        <motion.div className="absolute bottom-0 left-0 h-px bg-gradient-to-r from-transparent via-primary to-transparent" initial={{
        scaleX: 0
      }} animate={{
        scaleX: isScrolled ? 1 : 0
      }} transition={{
        duration: 0.5
      }} />
      </div>
    </motion.header>;
}