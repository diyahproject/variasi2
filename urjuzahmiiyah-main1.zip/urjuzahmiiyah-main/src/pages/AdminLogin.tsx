import { useState } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Shield, Lock, Mail, Smartphone } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AdminLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [otp, setOtp] = useState("");
  const [step, setStep] = useState<"credentials" | "otp">("credentials");
  const [loading, setLoading] = useState(false);
  const [userInfo, setUserInfo] = useState<any>(null);
  const navigate = useNavigate();
  const { toast } = useToast();

  const validCredentials = [
    { username: "superadmin", email: "admin@example.com", role: "superadmin" },
    { username: "admin1", email: "admin1@example.com", role: "admin" }
  ];

  const handleCredentialsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const user = validCredentials.find(cred => 
        cred.username === username && password === 'Admin123!'
      );

      if (!user) {
        throw new Error('Username atau password salah');
      }

      // Generate OTP
      const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
      sessionStorage.setItem("expectedOtp", otpCode);
      sessionStorage.setItem("tempUser", JSON.stringify(user));

      setUserInfo(user);
      
      toast({
        title: "OTP Dikirim",
        description: `Kode OTP: ${otpCode} (Demo - biasanya dikirim ke ${user.email})`,
        duration: 10000
      });

      setStep("otp");
    } catch (error: any) {
      toast({
        title: "Login Gagal",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleOtpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const expectedOtp = sessionStorage.getItem("expectedOtp");
      
      if (otp !== expectedOtp) {
        throw new Error('Kode OTP tidak valid');
      }

      const user = JSON.parse(sessionStorage.getItem("tempUser") || '{}');

      // Set login session
      const loginData = {
        userId: Date.now().toString(),
        username: user.username,
        email: user.email,
        role: user.role,
        loginTime: Date.now(),
        expiryTime: Date.now() + (8 * 60 * 60 * 1000) // 8 hours
      };
      
      sessionStorage.setItem("adminLogin", JSON.stringify(loginData));
      sessionStorage.removeItem("expectedOtp");
      sessionStorage.removeItem("tempUser");

      toast({
        title: "Login Berhasil",
        description: `Selamat datang, ${user.username}!`
      });

      navigate("/admin/dashboard");
    } catch (error: any) {
      toast({
        title: "Verifikasi Gagal",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/50 to-primary/5 flex items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <Card className="shadow-2xl border-0 bg-card/95 backdrop-blur-sm">
          <CardHeader className="text-center space-y-4 pb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-primary to-primary/60 rounded-full flex items-center justify-center mx-auto shadow-lg">
              <Shield className="h-10 w-10 text-primary-foreground" />
            </div>
            <CardTitle className="text-3xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
              Admin Panel
            </CardTitle>
            <p className="text-muted-foreground text-sm">
              {step === "credentials" 
                ? "Masukkan kredensial admin Anda"
                : "Masukkan kode OTP yang telah dikirim"
              }
            </p>
          </CardHeader>
          
          <CardContent className="space-y-6">
            {step === "credentials" ? (
              <form onSubmit={handleCredentialsSubmit} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="username" className="text-sm font-medium">Username</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="username"
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="pl-10 h-12 transition-all focus:ring-2 focus:ring-primary/20"
                      placeholder="Masukkan username"
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm font-medium">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="password"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 h-12 transition-all focus:ring-2 focus:ring-primary/20"
                      placeholder="Masukkan password"
                      required
                    />
                  </div>
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full h-12 text-base font-medium shadow-lg hover:shadow-xl transition-all" 
                  disabled={loading}
                >
                  {loading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                      Memverifikasi...
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4" />
                      Kirim OTP
                    </div>
                  )}
                </Button>
              </form>
            ) : (
              <form onSubmit={handleOtpSubmit} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="otp" className="text-sm font-medium">Kode OTP</Label>
                  <div className="relative">
                    <Smartphone className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="otp"
                      type="text"
                      value={otp}
                      onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                      className="pl-10 h-12 text-center text-lg font-mono tracking-widest transition-all focus:ring-2 focus:ring-primary/20"
                      placeholder="000000"
                      maxLength={6}
                      required
                    />
                  </div>
                  <p className="text-xs text-muted-foreground text-center">
                    Dikirim ke: {userInfo?.email}
                  </p>
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full h-12 text-base font-medium shadow-lg hover:shadow-xl transition-all" 
                  disabled={loading || otp.length !== 6}
                >
                  {loading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                      Memverifikasi...
                    </div>
                  ) : (
                    "Masuk Admin Panel"
                  )}
                </Button>
                
                <Button 
                  type="button" 
                  variant="outline" 
                  className="w-full h-11"
                  onClick={() => {
                    setStep("credentials");
                    setOtp("");
                  }}
                >
                  Kembali
                </Button>
              </form>
            )}
            
            <div className="pt-4 border-t border-border/50 text-center">
              <Button 
                variant="ghost" 
                onClick={() => navigate("/")}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                ← Kembali ke Beranda
              </Button>
            </div>
          </CardContent>
        </Card>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-6 p-4 bg-muted/50 rounded-lg border border-border/50"
        >
          <p className="text-sm text-muted-foreground text-center font-medium">
            Demo Login
          </p>
          <p className="text-xs text-muted-foreground text-center mt-1">
            Username: <span className="font-mono">superadmin</span> | 
            Password: <span className="font-mono">Admin123!</span>
          </p>
        </motion.div>
      </motion.div>
    </div>
  );
}