import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Download as DownloadIcon, 
  FileText, 
  Image, 
  BookOpen, 
  Calendar,
  ExternalLink
} from "lucide-react";

const Download = () => {
  const downloadItems = [
    {
      id: 'timeline-pdf',
      icon: FileText,
      title: 'Timeline Lengkap (PDF)',
      description: 'Timeline sejarah Islam lengkap dari 1 H hingga 1400 H',
      size: '2.5 MB',
      format: 'PDF',
      color: 'bg-red-100 text-red-700 border-red-200',
      onClick: () => console.log('Download timeline PDF')
    },
    {
      id: 'infographic',
      icon: Image,
      title: 'Infografis Sejarah',
      description: 'Koleksi infografis peristiwa penting dalam Islam',
      size: '15.8 MB',
      format: 'ZIP',
      color: 'bg-blue-100 text-blue-700 border-blue-200',
      onClick: () => console.log('Download infographics')
    },
    {
      id: 'study-guide',
      icon: BookOpen,
      title: 'Panduan Belajar',
      description: 'Panduan belajar sejarah Islam untuk siswa dan mahasiswa',
      size: '4.2 MB',
      format: 'PDF',
      color: 'bg-green-100 text-green-700 border-green-200',
      onClick: () => console.log('Download study guide')
    },
    {
      id: 'calendar',
      icon: Calendar,
      title: 'Kalender Hijriyah 2025',
      description: 'Kalender Hijriyah dengan peristiwa sejarah penting',
      size: '1.1 MB',
      format: 'PDF',
      color: 'bg-purple-100 text-purple-700 border-purple-200',
      onClick: () => console.log('Download calendar')
    },
  ];

  const externalResources = [
    {
      title: 'Perpustakaan Digital Islam',
      description: 'Akses ribuan kitab dan referensi sejarah Islam',
      url: 'https://example.com',
      icon: ExternalLink
    },
    {
      title: 'Museum Sejarah Islam',
      description: 'Tur virtual museum sejarah Islam di seluruh dunia',
      url: 'https://example.com',
      icon: ExternalLink
    },
    {
      title: 'Dokumenter Sejarah',
      description: 'Koleksi dokumenter sejarah Islam berkualitas tinggi',
      url: 'https://example.com',
      icon: ExternalLink
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 pb-24">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-6">
            <DownloadIcon className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold text-primary">Download</h1>
          </div>
          
          <p className="text-muted-foreground text-lg">
            Unduh materi pembelajaran dan sumber daya sejarah Islam
          </p>
        </motion.div>

        {/* Download Items */}
        <div className="mb-12">
          <h2 className="text-2xl font-semibold text-primary mb-6">Materi Download</h2>
          
          <div className="grid gap-6 md:grid-cols-2">
            {downloadItems.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-lg transition-all duration-300 group">
                  <CardHeader className="pb-4">
                    <div className="flex items-start gap-4">
                      <div className="p-3 rounded-lg bg-primary/10">
                        <item.icon className="h-6 w-6 text-primary" />
                      </div>
                      <div className="flex-grow">
                        <div className="flex items-center gap-2 mb-2">
                          <CardTitle className="text-lg">{item.title}</CardTitle>
                          <Badge variant="outline" className={item.color}>
                            {item.format}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {item.description}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Ukuran: {item.size}
                        </p>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <Button 
                      onClick={item.onClick}
                      className="w-full group-hover:shadow-md transition-all"
                    >
                      <DownloadIcon className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* External Resources */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <h2 className="text-2xl font-semibold text-primary mb-6">Sumber Eksternal</h2>
          
          <div className="space-y-4">
            {externalResources.map((resource, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + index * 0.1 }}
              >
                <Card className="hover:shadow-lg transition-all duration-300 group cursor-pointer">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="p-2 rounded-lg bg-accent">
                          <resource.icon className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-lg group-hover:text-primary transition-colors">
                            {resource.title}
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            {resource.description}
                          </p>
                        </div>
                      </div>
                      
                      <Button 
                        variant="outline"
                        onClick={() => window.open(resource.url, '_blank')}
                      >
                        Kunjungi
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Disclaimer */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="mt-12 p-6 bg-accent/30 rounded-lg border border-border/50"
        >
          <h3 className="font-semibold text-primary mb-2">Catatan Penting</h3>
          <p className="text-sm text-muted-foreground">
            Semua materi yang disediakan di sini telah melalui verifikasi dari para ahli sejarah Islam. 
            Gunakan materi ini untuk tujuan pendidikan dan pembelajaran. Jika Anda menggunakan materi 
            ini untuk publikasi, mohon cantumkan sumber yang sesuai.
          </p>
        </motion.div>
      </div>
    </div>
  );
};

export default Download;