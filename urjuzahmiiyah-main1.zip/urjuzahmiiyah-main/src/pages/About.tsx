import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, Users, Target, Heart, Star } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface AboutUs {
  id: string;
  title: string;
  content: string;
  mission: string | null;
  team_info: any;
}

interface TeamMember {
  name: string;
  role: string;
  description?: string;
  avatar?: string;
}

export default function About() {
  const [aboutData, setAboutData] = useState<AboutUs | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    fetchAboutData();
  }, []);

  const fetchAboutData = async () => {
    try {
      const { data, error } = await supabase
        .from('about_us')
        .select('*')
        .eq('is_active', true)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      setAboutData(data);
    } catch (error) {
      toast({
        title: "Error",
        description: "Gagal memuat informasi tentang kami",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const defaultTeam: TeamMember[] = [
    {
      name: "Dr. Ahmad Fauzi",
      role: "Ketua Tim",
      description: "Ahli sejarah Islam dengan pengalaman 15 tahun",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face"
    },
    {
      name: "Ustadz Muhammad Ridho",
      role: "Peneliti Senior",
      description: "Spesialis dalam penelitian hadits dan sirah",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face"
    },
    {
      name: "Siti Aminah",
      role: "Editor Konten",
      description: "Lulusan Ulum al-Quran dan Tafsir",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b332c877?w=150&h=150&fit=crop&crop=face"
    },
    {
      name: "Yusuf Ibrahim",
      role: "Developer",
      description: "Mengembangkan platform digital untuk edukasi Islam",
      avatar: "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=150&h=150&fit=crop&crop=face"
    }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          <div className="space-y-8">
            <Skeleton className="h-8 w-48" />
            <Card>
              <CardContent className="p-8">
                <Skeleton className="h-6 w-full mb-4" />
                <Skeleton className="h-32 w-full" />
              </CardContent>
            </Card>
            <div className="grid md:grid-cols-2 gap-6">
              {[...Array(4)].map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-6">
                    <Skeleton className="h-16 w-16 rounded-full mb-4" />
                    <Skeleton className="h-4 w-32 mb-2" />
                    <Skeleton className="h-3 w-24 mb-3" />
                    <Skeleton className="h-12 w-full" />
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  const teamMembers = aboutData?.team_info || defaultTeam;

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-8"
        >
          {/* Header */}
          <div className="space-y-4">
            <Button
              variant="ghost"
              onClick={() => navigate(-1)}
              className="mb-4"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Kembali
            </Button>
            
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                <Users className="h-8 w-8 text-primary" />
              </div>
              
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">
                  {aboutData?.title || "Tentang Kami"}
                </h1>
                <p className="text-muted-foreground text-lg">
                  Tim yang berdedikasi untuk menyebarkan pengetahuan sejarah Islam
                </p>
              </div>
            </div>
          </div>

          {/* Description */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Heart className="h-5 w-5 text-primary" />
                Deskripsi Organisasi
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed">
                {aboutData?.content || 
                  "Kami adalah tim yang berdedikasi untuk menyediakan platform edukasi sejarah Islam yang komprehensif dan mudah diakses. Dengan menggabungkan penelitian akademik yang mendalam dan teknologi modern, kami berusaha menjembatani kesenjangan antara pengetahuan klasik dan kebutuhan pembelajaran kontemporer."}
              </p>
            </CardContent>
          </Card>

          {/* Mission */}
          {aboutData?.mission && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  Misi Kami
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">
                  {aboutData.mission}
                </p>
              </CardContent>
            </Card>
          )}

          {/* Default Mission if not in database */}
          {!aboutData?.mission && (
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5 text-primary" />
                    Misi
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Menyediakan akses mudah dan komprehensif terhadap sejarah Islam melalui platform digital yang inovatif dan edukatif.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Star className="h-5 w-5 text-primary" />
                    Visi
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Menjadi platform rujukan utama untuk pembelajaran sejarah Islam yang menginspirasi generasi masa depan.
                  </p>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Team Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                Tim Inti
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                {teamMembers.map((member: TeamMember, index: number) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex gap-4 p-4 rounded-lg border border-border hover:bg-accent/50 transition-colors"
                  >
                    <div className="flex-shrink-0">
                      <div className="w-16 h-16 rounded-full bg-primary/10 overflow-hidden">
                        {member.avatar ? (
                          <img 
                            src={member.avatar} 
                            alt={member.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Users className="h-8 w-8 text-primary" />
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground mb-1">
                        {member.name}
                      </h3>
                      <Badge variant="secondary" className="mb-2">
                        {member.role}
                      </Badge>
                      {member.description && (
                        <p className="text-sm text-muted-foreground">
                          {member.description}
                        </p>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Contact Section */}
          <Card className="bg-accent/50">
            <CardContent className="p-8 text-center">
              <h3 className="text-xl font-semibold text-foreground mb-2">
                Hubungi Kami
              </h3>
              <p className="text-muted-foreground mb-4">
                Ada pertanyaan atau ingin berkolaborasi? Kami senang mendengar dari Anda
              </p>
              <Button onClick={() => navigate('/feedback')}>
                Kirim Pesan
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}