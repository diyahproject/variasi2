import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Shield, 
  LogOut, 
  Home, 
  Calendar, 
  Grid3X3, 
  MessageSquare, 
  Users, 
  FileText,
  Star,
  Clock,
  Settings,
  Image,
  Edit3,
  Save,
  Upload,
  Eye,
  Trash2,
  Plus
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { ContentManager } from "@/components/admin/ContentManager";
import { MediaManager } from "@/components/admin/MediaManager";
import { UserManager } from "@/components/admin/UserManager";
import { SettingsManager } from "@/components/admin/SettingsManager";

export default function AdminDashboard() {
  const [loginInfo, setLoginInfo] = useState<any>(null);
  const [timeLeft, setTimeLeft] = useState<string>("");
  const [activeTab, setActiveTab] = useState("content");
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const checkAuth = () => {
      const adminLogin = sessionStorage.getItem("adminLogin");
      
      if (!adminLogin) {
        navigate("/admin/login");
        return;
      }

      const loginData = JSON.parse(adminLogin);
      const now = Date.now();
      
      if (now > loginData.expiryTime) {
        sessionStorage.removeItem("adminLogin");
        toast({
          title: "Sesi Berakhir",
          description: "Sesi admin telah berakhir, silakan login kembali",
          variant: "destructive"
        });
        navigate("/admin/login");
        return;
      }

      setLoginInfo(loginData);
    };

    checkAuth();
    const interval = setInterval(checkAuth, 60000); // Check every minute
    return () => clearInterval(interval);
  }, [navigate, toast]);

  useEffect(() => {
    if (!loginInfo) return;

    const updateTimer = () => {
      const now = Date.now();
      const timeRemaining = loginInfo.expiryTime - now;
      
      if (timeRemaining <= 0) {
        setTimeLeft("Sesi berakhir");
        return;
      }

      const hours = Math.floor(timeRemaining / (1000 * 60 * 60));
      const minutes = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60));
      setTimeLeft(`${hours}j ${minutes}m`);
    };

    updateTimer();
    const timer = setInterval(updateTimer, 1000);
    return () => clearInterval(timer);
  }, [loginInfo]);

  const handleLogout = () => {
    sessionStorage.removeItem("adminLogin");
    toast({
      title: "Logout Berhasil",
      description: "Anda telah keluar dari admin panel"
    });
    navigate("/");
  };

  if (!loginInfo) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const adminMenus = [
    {
      id: "content",
      title: "Manajemen Konten",
      description: "Kelola semua konten website",
      icon: Edit3,
      color: "from-blue-500 to-blue-600"
    },
    {
      id: "media",
      title: "Media & Gambar",
      description: "Upload dan kelola file media",
      icon: Image,
      color: "from-green-500 to-green-600"
    },
    {
      id: "users",
      title: "Manajemen User",
      description: "Kelola admin dan tim",
      icon: Users,
      color: "from-purple-500 to-purple-600",
      superadminOnly: true
    },
    {
      id: "settings",
      title: "Pengaturan",
      description: "Konfigurasi sistem",
      icon: Settings,
      color: "from-orange-500 to-orange-600"
    }
  ];

  const availableMenus = adminMenus.filter(menu => 
    !menu.superadminOnly || loginInfo.role === 'superadmin'
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/50 to-primary/5">
      {/* Header */}
      <div className="border-b border-border/50 bg-card/95 backdrop-blur-sm shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary/60 rounded-lg flex items-center justify-center">
                <Shield className="h-5 w-5 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">Admin Panel</h1>
                <p className="text-sm text-muted-foreground">
                  {loginInfo.username} • {loginInfo.role} • Sisa waktu: {timeLeft}
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.open("/", "_blank")}
                className="flex items-center gap-2"
              >
                <Eye className="h-4 w-4" />
                Preview
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="flex items-center gap-2 text-destructive hover:text-destructive"
              >
                <LogOut className="h-4 w-4" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-6 py-8">
        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {availableMenus.map((menu) => {
            const IconComponent = menu.icon;
            return (
              <motion.div
                key={menu.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <Card 
                  className="cursor-pointer hover:shadow-lg transition-all border-0 bg-gradient-to-br from-card to-card/80 backdrop-blur-sm group"
                  onClick={() => setActiveTab(menu.id)}
                >
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${menu.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                        <IconComponent className="h-6 w-6 text-white" />
                      </div>
                      {activeTab === menu.id && (
                        <Badge variant="default" className="bg-primary/10 text-primary border-primary/20">
                          Aktif
                        </Badge>
                      )}
                    </div>
                    <h3 className="font-semibold text-foreground mb-2">{menu.title}</h3>
                    <p className="text-sm text-muted-foreground">{menu.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Tabs Content */}
        <Card className="border-0 bg-card/95 backdrop-blur-sm shadow-lg">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <CardHeader className="border-b border-border/50">
              <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:grid-cols-none lg:inline-flex bg-muted/50">
                {availableMenus.map((menu) => (
                  <TabsTrigger 
                    key={menu.id} 
                    value={menu.id}
                    className="flex items-center gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                  >
                    <menu.icon className="h-4 w-4" />
                    <span className="hidden sm:inline">{menu.title}</span>
                  </TabsTrigger>
                ))}
              </TabsList>
            </CardHeader>

            <CardContent className="p-6">
              <TabsContent value="content" className="mt-0">
                <ContentManager />
              </TabsContent>

              <TabsContent value="media" className="mt-0">
                <MediaManager />
              </TabsContent>

              {loginInfo.role === 'superadmin' && (
                <TabsContent value="users" className="mt-0">
                  <UserManager />
                </TabsContent>
              )}

              <TabsContent value="settings" className="mt-0">
                <SettingsManager />
              </TabsContent>
            </CardContent>
          </Tabs>
        </Card>
      </div>
    </div>
  );
}