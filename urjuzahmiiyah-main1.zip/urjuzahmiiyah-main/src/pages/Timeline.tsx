import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useParams, useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, MapPin, Clock, Users, ArrowLeft, ChevronDown, Swords, Crown, ZoomIn, Book, Map, Share, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AnimatedHeader } from "@/components/AnimatedHeader";

import { useIsMobile } from "@/hooks/use-mobile";
interface Event {
  id: string;
  title: string;
  subtitle: string;
  hijri_year: number;
  hijri_month: string;
  location: string;
  duration: string;
  participants: string[];
  description: string;
  image_url: string;
}
export default function Timeline() {
  const {
    year
  } = useParams();
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [events, setEvents] = useState<Event[]>([]);
  const [hijriYears, setHijriYears] = useState<number[]>([]);
  const [selectedYear, setSelectedYear] = useState<number | null>(null);
  useEffect(() => {
    const fetchHijriYears = async () => {
      const {
        data
      } = await supabase.from('hijri_years').select('year_number').eq('is_active', true).order('year_number');
      if (data) {
        const years = data.map(year => year.year_number);
        setHijriYears(years);

        // Set initial year from URL or first year
        const initialYear = year ? parseInt(year) : years[0];
        setSelectedYear(initialYear);
      }
    };
    fetchHijriYears();

    // Real-time subscription for hijri_years
    const yearsSubscription = supabase.channel('hijri_years_changes').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'hijri_years'
    }, () => fetchHijriYears()).subscribe();
    return () => {
      yearsSubscription.unsubscribe();
    };
  }, [year]);
  useEffect(() => {
    const fetchEvents = async () => {
      if (!selectedYear) return;
      const {
        data
      } = await supabase.from('events').select('*').eq('hijri_year', selectedYear).eq('is_active', true).order('hijri_month');
      if (data) {
        setEvents(data);
      }
    };
    fetchEvents();

    // Real-time subscription for events
    const eventsSubscription = supabase.channel('events_changes').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'events'
    }, () => fetchEvents()).subscribe();
    return () => {
      eventsSubscription.unsubscribe();
    };
  }, [selectedYear]);
  const handleEventClick = (eventId: string) => {
    navigate(`/event/${eventId}`);
  };
  const handleYearChange = (newYear: number) => {
    setSelectedYear(newYear);
    navigate(`/timeline/${newYear}`);
  };
  return <div className="min-h-screen bg-background pb-24">
      <AnimatedHeader />
      
      
      <div className="container mx-auto px-6 py-8">
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} animate={{
        opacity: 1,
        y: 0
      }} className="space-y-8">
          {/* Header */}
          <div className="flex items-center gap-4 mb-8">
            <Button variant="outline" size="icon" onClick={() => navigate('/')} className="rounded-full">
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div className="text-center flex-1">
              <div className="flex items-center justify-center gap-3 mb-2">
                <Calendar className="h-8 w-8 text-primary" />
                <h1 className="text-4xl font-bold text-primary">Timeline Sejarah Islam</h1>
              </div>
              <p className="text-lg text-muted-foreground">
                Jelajahi peristiwa bersejarah dalam Islam berdasarkan tahun Hijriyah
              </p>
            </div>
          </div>

          {/* New Spiral Carousel */}
          <div className="mb-8 md:mb-16 w-full">
            <div className="rounded-[20px] p-[30px] relative shadow-[0_10px_30px_rgba(0,0,0,0.05)]">
              <div 
                className="relative h-[400px] md:h-[500px] flex items-center justify-center touch-pan-y select-none"
                style={{ perspective: '1200px' }}
              >
                {hijriYears.slice(0, 5).map((yearNum, index) => {
                  const currentIndex = hijriYears.findIndex(y => y === selectedYear);
                  const relativeIndex = (index - currentIndex + hijriYears.length) % hijriYears.length;
                  const isActive = selectedYear === yearNum;
                  
                  let transform = '';
                  let zIndex = 1;
                  
                  if (relativeIndex === 0) {
                    // Active slide (center)
                    transform = 'translateZ(50px) scale(1.2)';
                    zIndex = 5;
                  } else if (relativeIndex === 1) {
                    // Right side
                    transform = isMobile ? 'translateX(150px) translateZ(-50px) rotateY(-20deg) scale(0.8)' : 'translateX(180px) translateZ(-50px) rotateY(-20deg) scale(0.8)';
                    zIndex = 4;
                  } else if (relativeIndex === hijriYears.length - 1) {
                    // Left side
                    transform = isMobile ? 'translateX(-150px) translateZ(-50px) rotateY(20deg) scale(0.8)' : 'translateX(-180px) translateZ(-50px) rotateY(20deg) scale(0.8)';
                    zIndex = 4;
                  } else if (relativeIndex === 2) {
                    // Far right
                    transform = isMobile ? 'translateX(250px) translateZ(-100px) rotateY(-40deg) scale(0.6)' : 'translateX(320px) translateZ(-100px) rotateY(-40deg) scale(0.6)';
                    zIndex = 3;
                  } else if (relativeIndex === hijriYears.length - 2) {
                    // Far left
                    transform = isMobile ? 'translateX(-250px) translateZ(-100px) rotateY(40deg) scale(0.6)' : 'translateX(-320px) translateZ(-100px) rotateY(40deg) scale(0.6)';
                    zIndex = 3;
                  } else {
                    // Hidden
                    transform = 'translateZ(-200px) scale(0.4)';
                    zIndex = 1;
                  }
                  
                  const cardWidth = isMobile ? '180px' : '280px';
                  const cardHeight = isMobile ? '280px' : '400px';
                  
                  return (
                    <div
                      key={yearNum}
                      className={`absolute bg-gray-50 rounded-[20px] p-[10px] overflow-hidden cursor-grab transition-all duration-1000 ease-out shadow-[0_15px_30px_rgba(0,0,0,0.1)] hover:shadow-[0_25px_50px_rgba(0,0,0,0.2)] ${
                        isActive ? 'cursor-auto shadow-[0_25px_50px_rgba(0,0,0,0.2)]' : ''
                      }`}
                      style={{
                        width: cardWidth,
                        height: cardHeight,
                        transform,
                        zIndex,
                        transformStyle: 'preserve-3d',
                      }}
                      onClick={() => !isActive && handleYearChange(yearNum)}
                    >
                      <div className="w-full h-full bg-cover bg-center bg-no-repeat rounded-[15px] border border-dashed border-gray-300 flex items-center justify-center text-gray-600 text-lg text-center p-5"
                           style={{
                             backgroundImage: `url('https://placehold.co/280x400/CCCCCC/333333?text=${yearNum}+H')`
                           }}>
                        <div className="text-center bg-black/50 rounded-xl p-3 md:p-4 backdrop-blur-sm">
                          <div className={`${isMobile ? 'text-xl' : 'text-3xl'} font-bold text-white mb-1`}>
                            {yearNum}
                          </div>
                          <div className={`${isMobile ? 'text-xs' : 'text-base'} text-white/80 font-semibold`}>
                            Hijriyah
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
                
                {/* Navigation Controls */}
                <button
                  className="absolute left-[10px] md:left-[20px] top-1/2 transform -translate-y-1/2 bg-black/10 border-2 border-black/20 w-[40px] h-[40px] md:w-[60px] md:h-[60px] rounded-full text-gray-800 text-base md:text-2xl cursor-pointer transition-all duration-300 backdrop-blur-sm z-10 flex items-center justify-center shadow-[0_5px_15px_rgba(0,0,0,0.1)] hover:bg-black/20 hover:scale-110 hover:shadow-[0_10px_20px_rgba(0,0,0,0.15)]"
                  onClick={() => {
                    const currentIndex = hijriYears.findIndex(y => y === selectedYear);
                    const newIndex = (currentIndex - 1 + hijriYears.length) % hijriYears.length;
                    handleYearChange(hijriYears[newIndex]);
                  }}
                >
                  ‹
                </button>
                
                <button
                  className="absolute right-[10px] md:right-[20px] top-1/2 transform -translate-y-1/2 bg-black/10 border-2 border-black/20 w-[40px] h-[40px] md:w-[60px] md:h-[60px] rounded-full text-gray-800 text-base md:text-2xl cursor-pointer transition-all duration-300 backdrop-blur-sm z-10 flex items-center justify-center shadow-[0_5px_15px_rgba(0,0,0,0.1)] hover:bg-black/20 hover:scale-110 hover:shadow-[0_10px_20px_rgba(0,0,0,0.15)]"
                  onClick={() => {
                    const currentIndex = hijriYears.findIndex(y => y === selectedYear);
                    const newIndex = (currentIndex + 1) % hijriYears.length;
                    handleYearChange(hijriYears[newIndex]);
                  }}
                >
                  ›
                </button>
                
                {/* Indicators */}
                <div className="absolute bottom-[20px] left-1/2 transform -translate-x-1/2 flex gap-2 md:gap-3 z-10 bg-black/5 rounded-[15px] py-2 px-3 md:px-4 border border-black/10 shadow-[0_5px_15px_rgba(0,0,0,0.05)]">
                  {hijriYears.slice(0, 5).map((yearNum, index) => {
                    const currentIndex = hijriYears.findIndex(y => y === selectedYear);
                    const isCurrentActive = index === currentIndex;
                    
                    return (
                      <div
                        key={yearNum}
                        className={`w-[10px] h-[10px] md:w-3 md:h-3 rounded-full cursor-pointer transition-all duration-300 border-2 border-black/10 ${
                          isCurrentActive 
                            ? 'bg-gray-800 scale-[1.3] shadow-[0_4px_8px_rgba(0,0,0,0.15)]' 
                            : 'bg-black/30'
                        }`}
                        onClick={() => handleYearChange(yearNum)}
                      />
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Events List - Enhanced Version */}
          <EventList selectedYear={selectedYear} />
        </motion.div>
      </div>
    </div>;
}
const EventList = ({
  selectedYear
}: {
  selectedYear: number | null;
}) => {
  const [visibleEvents, setVisibleEvents] = useState<number[]>([]);
  const [expandedEvent, setExpandedEvent] = useState<number | null>(null);
  const [mapZoom, setMapZoom] = useState<number | null>(null);
  const events = [{
    id: 1,
    title: "Perang Khandaq (Ahzab)",
    subtitle: "Keteguhan Iman di Tengah Kepungan",
    date: "25 Juli 2025",
    location: "Madinah Al-Munawwarah",
    duration: "1 bulan",
    time: "Syawal 5 H",
    icon: Swords,
    participants: ["Muslimin", "Quraisy", "Ghatafan", "Banu Nadhir", "Yahudi"],
    mapPreview: "🗺️ Peta Madinah Kuno",
    description: ["Perang Khandaq atau Perang Ahzab merupakan salah satu peperangan besar yang dihadapi umat Islam pada masa Rasulullah SAW. Perang ini terjadi ketika koalisi besar suku-suku Arab bersatu untuk menyerang Madinah.", "Strategi unik yang digunakan dalam perang ini adalah penggalian parit (khandaq) di sekeliling Madinah atas saran Salman Al-Farisi yang terinspirasi dari teknik perang Persia."],
    strategies: ["Penggalian parit sepanjang 5.5 km di sekitar Madinah", "Penempatan pasukan di titik-titik strategis", "Diplomasi untuk memecah koalisi musuh"],
    trivia: [{
      icon: "💡",
      title: "Tahukah kamu?",
      content: "Parit Khandaq digali sepanjang 5.5 km — strategi perang yang tak pernah digunakan sebelumnya oleh bangsa Arab."
    }, {
      icon: "⚔️",
      title: "Fakta Menarik",
      content: "Perang ini berlangsung selama 27 hari tanpa pertempuran besar, hanya berupa pengepungan dan serangan sporadis."
    }],
    references: [{
      title: "Sirah Nabawiyah",
      author: "Ibnu Hisyam",
      year: "213 H",
      publisher: "Dar Al-Kutub Al-Ilmiyyah",
      pages: "vol 2, hal 214-298"
    }, {
      title: "Al-Bidayah wan Nihayah",
      author: "Ibnu Katsir",
      year: "774 H",
      publisher: "Dar Ihya At-Turats",
      pages: "vol 4, hal 104-156"
    }]
  }, {
    id: 2,
    title: "Fathu Makkah",
    subtitle: "Kemenangan Tanpa Pertumpahan Darah",
    date: "28 Juli 2025",
    location: "Makkah Al-Mukarramah",
    duration: "3 hari",
    time: "Ramadhan 8 H",
    icon: Crown,
    participants: ["Muslimin", "Quraisy Makkah", "Banu Bakr", "Banu Khuza'ah"],
    mapPreview: "🗺️ Peta Makkah Kuno",
    description: ["Fathu Makkah atau Penaklukan Makkah merupakan peristiwa bersejarah yang menandai kemenangan besar umat Islam tanpa pertumpahan darah yang berarti.", "Peristiwa ini terjadi setelah Quraisy melanggar Perjanjian Hudaibiyah dengan menyerang Banu Khuza'ah yang merupakan sekutu kaum Muslimin."],
    strategies: ["Pergerakan pasukan secara diam-diam dari empat arah", "Strategi psikologis dengan menunjukkan kekuatan", "Kebijakan amnesti umum untuk penduduk Makkah"],
    trivia: [{
      icon: "🕌",
      title: "Tahukah kamu?",
      content: "Rasulullah SAW masuk Makkah dengan kepala tertunduk di atas untanya sebagai tanda kerendahan hati, bukan kesombongan."
    }],
    references: [{
      title: "Fiqh As-Sirah",
      author: "Muhammad Al-Ghazali",
      year: "1416 H",
      publisher: "Dar Al-Qalam",
      pages: "hal 398-445"
    }]
  }];
  useEffect(() => {
    events.forEach((_, index) => {
      setTimeout(() => {
        setVisibleEvents(prev => [...prev, index]);
      }, index * 150);
    });
  }, []);
  const toggleExpand = (eventId: number) => {
    setExpandedEvent(expandedEvent === eventId ? null : eventId);
  };
  const toggleMap = (eventId: number) => {
    setMapZoom(mapZoom === eventId ? null : eventId);
  };
  if (!selectedYear) {
    return <motion.div initial={{
      opacity: 0
    }} animate={{
      opacity: 1
    }} className="text-center py-16">
        <Calendar className="h-20 w-20 text-primary mx-auto mb-6 opacity-80" />
        <h3 className="text-2xl font-semibold text-foreground mb-4">
          Pilih Tahun Hijriyah
        </h3>
        <p className="text-muted-foreground text-lg">
          Pilih tahun di atas untuk melihat peristiwa bersejarah
        </p>
      </motion.div>;
  }
  return <div className="max-w-4xl mx-auto">
      {/* Header Cards - Hijriyah Style */}
      

      {/* Events List */}
      <div className="space-y-6">
        {events.map((event, index) => {
        const IconComponent = event.icon;
        const isVisible = visibleEvents.includes(index);
        const isExpanded = expandedEvent === event.id;
        const isMapZoomed = mapZoom === event.id;
        return <div key={event.id} className={`transform transition-all duration-700 ${isVisible ? 'translate-x-0 opacity-100' : 'translate-x-[-50px] opacity-0'}`} style={{
          transitionDelay: `${index * 100}ms`
        }}>
              <div className="bg-card backdrop-blur-sm rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden border border-border">
                {/* Main Content */}
                <div className="flex items-center p-4 cursor-pointer hover:bg-accent/10 transition-colors duration-200" onClick={() => toggleExpand(event.id)}>
                  {/* Animated Icon */}
                  <div className="flex-shrink-0 w-14 h-14 rounded-xl flex items-center justify-center mr-4 group-hover:scale-110 transition-all duration-300 shadow-md bg-primary">
                    <IconComponent className="w-7 h-7 text-primary-foreground animate-bounce" style={{
                  animationDuration: '2s',
                  animationDelay: `${index * 0.2}s`
                }} />
                  </div>

                  {/* Event Content */}
                  <div className="flex-grow">
                    <h3 className="text-lg font-bold text-foreground mb-1">
                      {event.title}
                    </h3>
                    <p className="text-sm font-medium text-muted-foreground italic">
                      {event.subtitle}
                    </p>
                  </div>

                  {/* Chevron */}
                  <ChevronDown className={`w-5 h-5 text-muted-foreground transform transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`} />
                </div>

                {/* Expanded Details */}
                <div className={`overflow-hidden transition-all duration-300 ${isExpanded ? 'max-h-none opacity-100' : 'max-h-0 opacity-0'}`}>
                  <div className="px-6 pb-6 border-t border-border">
                    {/* Location & Duration Card */}
                    <div className="mt-6 rounded-xl p-4 border bg-background border-border">
                      <h4 className="font-semibold text-foreground mb-3 flex items-center">
                        <MapPin className="w-5 h-5 mr-2 text-primary" />
                        Lokasi & Durasi
                      </h4>
                      <div className="space-y-2 mb-4">
                        <div className="flex items-center text-sm text-muted-foreground">
                          <span className="font-medium mr-2">📍 Lokasi:</span>
                          <span>{event.location}</span>
                        </div>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <span className="font-medium mr-2">⏰ Durasi:</span>
                          <span>{event.duration}</span>
                        </div>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <span className="font-medium mr-2">📅 Waktu:</span>
                          <span>{event.time}</span>
                        </div>
                      </div>

                      {/* Map Preview */}
                      <div className="bg-card rounded-lg p-3 border border-border">
                        <div className="flex items-center justify-between cursor-pointer hover:bg-accent/10 p-2 rounded" onClick={() => toggleMap(event.id)}>
                          <span className="text-sm font-medium text-foreground">{event.mapPreview}</span>
                          <ZoomIn className="w-4 h-4 text-muted-foreground" />
                        </div>
                        {isMapZoomed && <div className="mt-3 rounded-lg p-4 text-center bg-background">
                            <Map className="w-16 h-16 mx-auto text-muted-foreground mb-2" />
                            <p className="text-xs text-muted-foreground">Peta detail lokasi akan ditampilkan di sini</p>
                          </div>}
                      </div>
                    </div>

                    {/* Participants Section */}
                    <div className="mt-6">
                      <h4 className="font-semibold text-foreground mb-3 flex items-center">
                        <Users className="w-5 h-5 mr-2 text-primary" />
                        👥 Pihak Terlibat
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {event.participants.map((participant, idx) => <span key={idx} className="bg-card px-3 py-1 rounded-full text-sm text-foreground hover:shadow-sm transition-shadow border border-border">
                            {participant}
                          </span>)}
                      </div>
                    </div>

                    {/* Event Description */}
                    <div className="mt-6">
                      <h4 className="font-semibold text-foreground mb-3">📜 Deskripsi Peristiwa</h4>
                      <div className="space-y-4">
                        {event.description.map((paragraph, idx) => <div key={idx}>
                            <p className="text-muted-foreground leading-relaxed text-justify bg-card p-4 rounded-lg border border-border">{paragraph}</p>
                            
                            {/* Insert trivia between paragraphs */}
                            {idx < event.description.length - 1 && event.trivia[idx] && <div className="my-4 rounded-r-lg p-4 border-l-4 bg-background border-l-primary">
                                <div className="flex items-start">
                                  <span className="text-2xl mr-3">{event.trivia[idx].icon}</span>
                                  <div>
                                    <h5 className="font-semibold mb-1 text-primary">{event.trivia[idx].title}</h5>
                                    <p className="text-muted-foreground text-sm">{event.trivia[idx].content}</p>
                                  </div>
                                </div>
                              </div>}
                          </div>)}
                      </div>
                    </div>

                    {/* Strategies/Chronology */}
                    {event.strategies && <div className="mt-6">
                        <h4 className="font-semibold text-foreground mb-3">⚡ Strategi Utama</h4>
                        <div className="space-y-2">
                          {event.strategies.map((strategy, idx) => <div key={idx} className="flex items-start bg-card p-3 rounded-lg border border-border">
                              <span className="w-3 h-3 bg-green-500 dark:bg-white rounded-full mr-3 animate-pulse flex-shrink-0 mt-1"></span>
                              <p className="text-muted-foreground text-sm">{strategy}</p>
                            </div>)}
                        </div>
                      </div>}

                    {/* Remaining Trivia */}
                    {event.trivia.slice(event.description.length - 1).map((trivia, idx) => <div key={`extra-${idx}`} className="mt-4 rounded-r-lg p-4 border-l-4 bg-background border-l-primary">
                        <div className="flex items-start">
                          <span className="text-2xl mr-3">{trivia.icon}</span>
                          <div>
                            <h5 className="font-semibold mb-1 text-primary">{trivia.title}</h5>
                            <p className="text-muted-foreground text-sm">{trivia.content}</p>
                          </div>
                        </div>
                      </div>)}

                    {/* References */}
                    <div className="mt-6">
                      <h4 className="font-semibold text-foreground mb-3 flex items-center">
                        <Book className="w-5 h-5 mr-2 text-primary" />
                        📚 Referensi
                      </h4>
                      <div className="space-y-3">
                        {event.references.map((ref, idx) => <div key={idx} className="bg-card rounded-lg p-3 border border-primary">
                            <h5 className="font-medium text-foreground">{ref.title}</h5>
                            <p className="text-sm text-muted-foreground">Penulis: {ref.author}</p>
                            <p className="text-sm text-muted-foreground">Tahun: {ref.year} | Penerbit: {ref.publisher}</p>
                            <p className="text-sm text-muted-foreground">{ref.pages}</p>
                          </div>)}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="mt-6 pt-4 border-t border-border flex justify-between items-center">
                      <button 
                        onClick={() => {
                          const message = `Lihat peristiwa bersejarah: ${event.title} - ${event.subtitle}`;
                          const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(message)}`;
                          window.open(whatsappUrl, '_blank');
                        }}
                        className="bg-primary hover:bg-primary/90 text-primary-foreground px-6 py-3 rounded-lg text-sm font-medium transition-all duration-200 transform hover:scale-105 shadow-md flex items-center gap-2"
                      >
                        <Share className="w-4 h-4" />
                        Share ke WhatsApp
                      </button>
                      <button 
                        onClick={() => setExpandedEvent(null)}
                        className="bg-accent hover:bg-accent/90 text-accent-foreground px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 transform hover:scale-105 shadow-md flex items-center gap-2"
                      >
                        <X className="w-4 h-4" />
                        Tutup
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>;
      })}
      </div>

      {/* Footer */}
      
    </div>;
};