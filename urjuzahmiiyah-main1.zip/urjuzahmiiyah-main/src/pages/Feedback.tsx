import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, MessageSquare, Send, User, Mail } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export default function Feedback() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.message.trim()) {
      toast({
        title: "Error",
        description: "Pesan tidak boleh kosong",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);

    try {
      const { error } = await supabase
        .from('feedback')
        .insert([
          {
            name: formData.name.trim() || null,
            email: formData.email.trim() || null,
            message: formData.message.trim()
          }
        ]);

      if (error) throw error;

      toast({
        title: "Berhasil!",
        description: "Feedback Anda telah terkirim. Terima kasih atas masukannya!"
      });

      setFormData({ name: "", email: "", message: "" });
    } catch (error) {
      toast({
        title: "Error",
        description: "Gagal mengirim feedback. Silakan coba lagi.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-8"
        >
          {/* Header */}
          <div className="space-y-4">
            <Button
              variant="ghost"
              onClick={() => navigate(-1)}
              className="mb-4"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Kembali
            </Button>
            
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                <MessageSquare className="h-8 w-8 text-primary" />
              </div>
              
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">
                  Kritik & Saran
                </h1>
                <p className="text-muted-foreground text-lg">
                  Bantu kami meningkatkan kualitas aplikasi dengan memberikan feedback
                </p>
              </div>
            </div>
          </div>

          {/* Feedback Form */}
          <Card>
            <CardHeader>
              <CardTitle>Kirim Feedback</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nama (Opsional)</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="name"
                        name="name"
                        type="text"
                        value={formData.name}
                        onChange={handleChange}
                        className="pl-10"
                        placeholder="Masukkan nama Anda"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">Email (Opsional)</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleChange}
                        className="pl-10"
                        placeholder="nama@email.com"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="message">Pesan <span className="text-destructive">*</span></Label>
                  <Textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Tuliskan kritik, saran, atau pertanyaan Anda di sini..."
                    className="min-h-[120px] resize-none"
                    required
                  />
                  <p className="text-xs text-muted-foreground">
                    Minimal 10 karakter, maksimal 1000 karakter
                  </p>
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={loading || formData.message.length < 10}
                >
                  {loading ? (
                    "Mengirim..."
                  ) : (
                    <>
                      <Send className="h-4 w-4 mr-2" />
                      Kirim Feedback
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Info Section */}
          <Card className="bg-accent/50">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-2">
                Terima Kasih atas Partisipasinya!
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                Feedback Anda sangat berharga untuk pengembangan aplikasi ini. 
                Tim kami akan meninjau setiap masukan yang diberikan dan menggunakannya 
                untuk meningkatkan kualitas konten dan fitur aplikasi.
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}