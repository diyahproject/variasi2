import { AnimatedHeader } from "@/components/AnimatedHeader";
import HeroSection from "@/components/HeroSection";
import { SearchBar } from "@/components/SearchBar";
import { TimelineSection } from "@/components/TimelineSection";
import { CategoriesSection } from "@/components/CategoriesSection";
const Index = () => {
  const handleSearch = (query: string) => {
    console.log("Searching for:", query);
  };

  return (
    <div className="min-h-screen bg-background">
      <AnimatedHeader />
      
      <div className="container mx-auto px-6 space-y-20" style={{ backgroundColor: '#D9D2C6' }}>
        <HeroSection />
        <SearchBar onSearch={handleSearch} />
        <TimelineSection />
        <CategoriesSection />
      </div>
    </div>
  );
};

export default Index;
