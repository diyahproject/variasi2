import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useTheme } from "@/contexts/ThemeContext";
import { useNavigate } from "react-router-dom";
import { 
  Moon, 
  Sun, 
  Type, 
  HelpCircle, 
  MessageSquare, 
  Info, 
  Crown,
  Settings as SettingsIcon 
} from "lucide-react";

const Settings = () => {
  const { theme, setTheme, textSize, setTextSize } = useTheme();
  const navigate = useNavigate();

  const textSizeOptions = [
    { value: 'small', label: 'Kecil', preview: 'text-sm' },
    { value: 'medium', label: 'Sedang', preview: 'text-base' },
    { value: 'large', label: 'Besar', preview: 'text-lg' },
    { value: 'xl', label: 'Super Besar', preview: 'text-xl' },
  ] as const;

  const settingsItems = [
    {
      id: 'dark-mode',
      icon: theme === 'dark' ? Moon : Sun,
      title: 'Dark Mode',
      description: 'Beralih ke tema gelap untuk kenyamanan mata',
      action: (
        <Switch 
          checked={theme === 'dark'} 
          onCheckedChange={(checked) => setTheme(checked ? 'dark' : 'light')}
        />
      )
    },
    {
      id: 'text-size',
      icon: Type,
      title: 'Ukuran Teks',
      description: 'Atur ukuran teks untuk kenyamanan membaca',
      action: (
        <div className="flex flex-wrap gap-2">
          {textSizeOptions.map((option) => (
            <Badge
              key={option.value}
              variant={textSize === option.value ? "default" : "outline"}
              className={`cursor-pointer transition-all ${
                textSize === option.value 
                  ? "bg-primary text-primary-foreground" 
                  : "hover:bg-accent"
              }`}
              onClick={() => setTextSize(option.value)}
            >
              <span className={option.preview}>{option.label}</span>
            </Badge>
          ))}
        </div>
      )
    },
    {
      id: 'faq',
      icon: HelpCircle,
      title: 'FAQ',
      description: 'Pertanyaan yang sering diajukan',
      action: (
        <Button 
          variant="outline" 
          onClick={() => navigate('/faq')}
        >
          Lihat FAQ
        </Button>
      )
    },
    {
      id: 'feedback',
      icon: MessageSquare,
      title: 'Kritik & Saran',
      description: 'Kirimkan feedback untuk perbaikan aplikasi',
      action: (
        <Button 
          variant="outline" 
          onClick={() => navigate('/feedback')}
        >
          Kirim Feedback
        </Button>
      )
    },
    {
      id: 'about',
      icon: Info,
      title: 'Tentang Kami',
      description: 'Informasi tentang tim pengembang dan misi',
      action: (
        <Button 
          variant="outline" 
          onClick={() => navigate('/about')}
        >
          Selengkapnya
        </Button>
      )
    },
    {
      id: 'admin',
      icon: Crown,
      title: 'Akses Anggota Eksklusif',
      description: 'Masuk ke area khusus anggota premium',
      action: (
        <Button 
          variant="outline" 
          className="border-primary/50 text-primary hover:bg-primary/10"
          onClick={() => navigate('/admin/login')}
        >
          Masuk
        </Button>
      )
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-6 py-12 pb-28">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <div className="flex items-center gap-4 mb-8">
            <SettingsIcon className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold text-primary">Pengaturan</h1>
          </div>
          
          <p className="text-muted-foreground text-lg">
            Sesuaikan aplikasi sesuai preferensi Anda
          </p>
        </motion.div>

        <div className="space-y-6">
          {settingsItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="hover:shadow-xl hover:shadow-primary/10 transition-all duration-300 border-0 bg-gradient-to-r from-card to-accent/5">
                <CardHeader className="pb-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="p-3 rounded-xl bg-primary/10">
                        <item.icon className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <CardTitle className="text-xl">{item.title}</CardTitle>
                        <p className="text-muted-foreground mt-2">
                          {item.description}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  {item.action}
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mt-16 text-center"
        >
          <p className="text-muted-foreground">
            Aplikasi Sejarah Islam v1.0.0
          </p>
        </motion.div>
      </div>
    </div>
  );
};

export default Settings;