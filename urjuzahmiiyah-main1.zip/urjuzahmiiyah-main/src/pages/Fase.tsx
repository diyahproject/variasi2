import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useParams, useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Calendar, MapPin, Users, Clock, Share2, Book } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface Category {
  id: string;
  name: string;
  description: string;
  image_url: string;
  badge_text: string;
}

interface Event {
  id: string;
  title: string;
  subtitle: string;
  hijri_year: number;
  hijri_month: string;
  location: string;
  duration: string;
  participants: string[];
  description: string;
  image_url: string;
  trivia: any[];
  event_references: any[];
  latitude: number;
  longitude: number;
}

export default function Fase() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [expandedEvents, setExpandedEvents] = useState<Set<string>>(new Set());
  const { categoryId } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const fetchCategories = async () => {
      const { data } = await supabase
        .from('categories')
        .select('*')
        .eq('is_active', true)
        .order('sort_order');
      if (data) {
        setCategories(data);
      }
    };
    fetchCategories();
  }, []);

  useEffect(() => {
    if (categoryId) {
      const fetchCategoryAndEvents = async () => {
        // Fetch category details
        const { data: categoryData } = await supabase
          .from('categories')
          .select('*')
          .eq('id', categoryId)
          .eq('is_active', true)
          .single();
        
        if (categoryData) {
          setSelectedCategory(categoryData);
        }

        // Fetch events for this category
        const { data: eventsData } = await supabase
          .from('events')
          .select('*')
          .eq('category_id', categoryId)
          .eq('is_active', true)
          .order('hijri_year');
        
        if (eventsData) {
          setEvents(eventsData);
        }
      };
      fetchCategoryAndEvents();
    } else {
      setSelectedCategory(null);
      setEvents([]);
    }
  }, [categoryId]);

  const handleCategoryClick = (category: Category) => {
    navigate(`/fase/${category.id}`);
  };

  const handleEventClick = (eventId: string) => {
    navigate(`/event/${eventId}`);
  };

  const toggleExpand = (eventId: string) => {
    setExpandedEvents(prev => {
      const newSet = new Set(prev);
      if (newSet.has(eventId)) {
        newSet.delete(eventId);
      } else {
        newSet.add(eventId);
      }
      return newSet;
    });
  };

  const handleShare = (event: Event) => {
    const text = `🕌 *${event.title}*\n\n📅 ${event.hijri_year}H - ${event.hijri_month}\n📍 ${event.location}\n\n${event.description.substring(0, 100)}...\n\nLihat detail lengkap: ${window.location.origin}/event/${event.id}`;
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(whatsappUrl, '_blank');
  };

  if (!categoryId) {
    // Show categories list
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 p-4 pb-20">
        <motion.div 
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }} 
          transition={{ duration: 0.6 }}
          className="max-w-6xl mx-auto space-y-8"
        >
          <div className="text-center space-y-4">
            <motion.h1 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-4xl font-bold bg-gradient-to-r from-primary via-primary to-accent bg-clip-text text-transparent"
            >
              Fase Sejarah Islam
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-muted-foreground text-lg"
            >
              Jelajahi peristiwa bersejarah berdasarkan periode dan kategori
            </motion.p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {categories.map((category, index) => (
              <motion.div
                key={category.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
              >
                <Card 
                  className="group cursor-pointer transition-all duration-300 hover:shadow-2xl hover:shadow-primary/40 hover:scale-[1.03] border-0 bg-gradient-to-br from-card via-card to-accent/10 overflow-hidden"
                  onClick={() => handleCategoryClick(category)}
                >
                  <CardContent className="p-0">
                    <div className="relative h-56 overflow-hidden">
                      <img 
                        src={category.image_url || `https://images.unsplash.com/photo-1466442929976-97f336a657be?w=600&h=400&fit=crop`}
                        alt={category.name}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
                      
                      {category.badge_text && (
                        <Badge className="absolute top-4 left-4 bg-primary/95 text-primary-foreground border-0 shadow-lg backdrop-blur-sm px-3 py-1 font-semibold">
                          {category.badge_text.includes('610') ? '5 M - 7 M' : 
                           category.badge_text.includes('M') ? category.badge_text.replace(/\s*-\s*\w+.*$/, '') : 
                           category.badge_text}
                        </Badge>
                      )}

                      <div className="absolute inset-0 bg-primary/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    </div>
                    
                    <div className="p-6 space-y-4">
                      <h3 className="font-bold text-xl text-foreground group-hover:text-primary transition-colors duration-300">
                        {category.name}
                      </h3>
                      {category.description && (
                        <p className="text-muted-foreground text-sm line-clamp-2">
                          {category.description}
                        </p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    );
  }

  // Show events for selected category
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 p-4 pb-20">
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        transition={{ duration: 0.6 }}
        className="max-w-4xl mx-auto space-y-8"
      >
        <div className="flex items-center gap-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/fase')}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Kembali
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-primary">{selectedCategory?.name}</h1>
            <p className="text-muted-foreground">{events.length} peristiwa ditemukan</p>
          </div>
        </div>

        <div className="space-y-6">
          {events.map((event, index) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`transform transition-all duration-700 translate-x-0 opacity-100`}
            >
              <div className="bg-card backdrop-blur-sm rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden border border-border">
                {/* Main Content */}
                <div className="flex items-center p-4 cursor-pointer hover:bg-accent/10 transition-colors duration-200" onClick={() => toggleExpand(event.id)}>
                  {/* Event Image */}
                  <div className="flex-shrink-0 w-14 h-14 rounded-xl overflow-hidden mr-4 shadow-md">
                    <img 
                      src={event.image_url || `https://images.unsplash.com/photo-1566552881560-0be862a7c445?w=200&h=200&fit=crop`}
                      alt={event.title}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Event Content */}
                  <div className="flex-grow">
                    <h3 className="text-lg font-bold text-foreground mb-1">
                      {event.title}
                    </h3>
                    {event.subtitle && (
                      <p className="text-sm font-medium text-muted-foreground italic">
                        {event.subtitle}
                      </p>
                    )}
                  </div>

                  {/* Share Button */}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleShare(event);
                    }}
                    className="text-muted-foreground hover:text-primary mr-2"
                  >
                    <Share2 className="h-4 w-4" />
                  </Button>

                  {/* Chevron */}
                  <div className={`w-5 h-5 text-muted-foreground transform transition-transform duration-300 ${expandedEvents.has(event.id) ? 'rotate-180' : ''}`}>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="6,9 12,15 18,9"></polyline>
                    </svg>
                  </div>
                </div>

                {/* Expanded Details */}
                <div className={`overflow-hidden transition-all duration-300 ${expandedEvents.has(event.id) ? 'max-h-none opacity-100' : 'max-h-0 opacity-0'}`}>
                  <div className="px-6 pb-6 border-t border-border">
                    {/* Location & Duration Card */}
                    <div className="mt-6 rounded-xl p-4 border bg-background border-border">
                      <h4 className="font-semibold text-foreground mb-3 flex items-center">
                        <MapPin className="w-5 h-5 mr-2 text-primary" />
                        Lokasi & Durasi
                      </h4>
                      <div className="space-y-2 mb-4">
                        {event.location && (
                          <div className="flex items-center text-sm text-muted-foreground">
                            <span className="font-medium mr-2">📍 Lokasi:</span>
                            <span>{event.location}</span>
                          </div>
                        )}
                        {event.duration && (
                          <div className="flex items-center text-sm text-muted-foreground">
                            <span className="font-medium mr-2">⏰ Durasi:</span>
                            <span>{event.duration}</span>
                          </div>
                        )}
                        <div className="flex items-center text-sm text-muted-foreground">
                          <span className="font-medium mr-2">📅 Waktu:</span>
                          <span>{event.hijri_year}H {event.hijri_month && `- ${event.hijri_month}`}</span>
                        </div>
                      </div>
                    </div>

                    {/* Description */}
                    <div className="mt-6 rounded-xl p-4 border bg-background border-border">
                      <h4 className="font-semibold text-foreground mb-3 flex items-center">
                        <Book className="w-5 h-5 mr-2 text-primary" />
                        Deskripsi
                      </h4>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {event.description}
                      </p>
                    </div>

                    {/* Participants */}
                    {event.participants && event.participants.length > 0 && (
                      <div className="mt-6 rounded-xl p-4 border bg-background border-border">
                        <h4 className="font-semibold text-foreground mb-3 flex items-center">
                          <Users className="w-5 h-5 mr-2 text-primary" />
                          Tokoh Terlibat
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {event.participants.map((participant, idx) => (
                            <Badge key={idx} variant="secondary" className="text-xs">
                              {participant}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="mt-6 flex gap-3">
                      <Button
                        size="sm"
                        onClick={() => handleEventClick(event.id)}
                        className="flex-1"
                      >
                        Detail Lengkap
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {events.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Belum ada peristiwa dalam kategori ini.</p>
          </div>
        )}
      </motion.div>
    </div>
  );
}