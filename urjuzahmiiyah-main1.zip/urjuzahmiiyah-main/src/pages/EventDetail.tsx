import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, MapPin, Clock, Users, Share2, Lightbulb, BookOpen } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface Event {
  id: string;
  title: string;
  subtitle: string;
  hijri_year: number;
  hijri_month: string;
  location: string;
  duration: string;
  participants: string[];
  description: string;
  image_url: string;
  trivia: any[];
  event_references: any[];
  latitude: number;
  longitude: number;
}

export default function EventDetail() {
  const { eventId } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [event, setEvent] = useState<Event | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchEvent = async () => {
      if (!eventId) return;

      try {
        const { data, error } = await supabase
          .from('events')
          .select('*')
          .eq('id', eventId)
          .eq('is_active', true)
          .single();

        if (error) throw error;
        setEvent(data);
      } catch (error) {
        toast({
          title: "Error",
          description: "Gagal memuat detail peristiwa",
          variant: "destructive"
        });
        navigate('/timeline');
      } finally {
        setLoading(false);
      }
    };

    fetchEvent();
  }, [eventId, navigate, toast]);

  const handleShare = () => {
    if (!event) return;
    
    const shareText = `🕌 ${event.title}\n\n${event.subtitle}\n\n📅 ${event.hijri_year} H - ${event.hijri_month}\n📍 ${event.location}\n\n${event.description.substring(0, 200)}...\n\n🌐 Timeline Sejarah Islam`;
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(shareText)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleMapClick = () => {
    if (!event?.latitude || !event?.longitude) return;
    const googleMapsUrl = `https://www.google.com/maps/@${event.latitude},${event.longitude},12z`;
    window.open(googleMapsUrl, '_blank');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!event) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Peristiwa tidak ditemukan</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="container mx-auto px-6 py-8 max-w-4xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 mb-8"
        >
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(-1)}
            className="rounded-full"
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Detail Peristiwa</h1>
            <p className="text-muted-foreground">Sejarah lengkap peristiwa bersejarah</p>
          </div>
        </motion.div>

        {/* Hero Image */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="relative mb-8 rounded-2xl overflow-hidden"
        >
          <img
            src={event.image_url}
            alt={event.title}
            className="w-full h-64 md:h-80 object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
          <div className="absolute bottom-6 left-6 text-white">
            <Badge className="mb-2 bg-primary/80 text-primary-foreground">
              {event.hijri_year} H - {event.hijri_month}
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-2">{event.title}</h2>
            <p className="text-xl text-white/90">{event.subtitle}</p>
          </div>
        </motion.div>

        <div className="grid gap-8">
          {/* Location & Duration Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-primary" />
                  Lokasi & Durasi
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Lokasi</p>
                    <p className="text-lg font-semibold">{event.location}</p>
                    {event.latitude && event.longitude && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleMapClick}
                        className="mt-2"
                      >
                        📍 Lihat di Peta
                      </Button>
                    )}
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Durasi</p>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <p className="text-lg font-semibold">{event.duration}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Participants */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  Pihak Terlibat
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {event.participants.map((participant, index) => (
                    <Badge key={index} variant="secondary" className="text-sm">
                      👥 {participant}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Description */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>Deskripsi Naratif</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose max-w-none">
                  <p className="text-foreground leading-relaxed text-lg whitespace-pre-line">
                    {event.description}
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Trivia */}
          {event.trivia && event.trivia.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
            >
              <Card className="bg-gradient-to-r from-accent/10 to-primary/10">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="h-5 w-5 text-accent" />
                    💡 Tahukah kamu?
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {event.trivia.map((trivia, index) => (
                      <div key={index} className="p-4 bg-background/50 rounded-lg">
                        <p className="text-foreground">
                          {typeof trivia === 'string' ? trivia.replace(/"/g, '') : JSON.stringify(trivia).replace(/"/g, '')}
                        </p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* References */}
          {event.event_references && event.event_references.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="h-5 w-5 text-primary" />
                    Referensi
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {event.event_references.map((ref, index) => (
                      <div key={index} className="p-4 border border-border rounded-lg">
                        <p className="text-foreground">
                          {typeof ref === 'string' ? ref.replace(/"/g, '') : JSON.stringify(ref).replace(/"/g, '')}
                        </p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Share Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="text-center"
          >
            <Separator className="mb-8" />
            <Button
              onClick={handleShare}
              size="lg"
              className="bg-green-600 hover:bg-green-700 text-white px-8 py-6"
            >
              <Share2 className="h-5 w-5 mr-2" />
              Share ke WhatsApp
            </Button>
          </motion.div>
        </div>
      </div>
    </div>
  );
}