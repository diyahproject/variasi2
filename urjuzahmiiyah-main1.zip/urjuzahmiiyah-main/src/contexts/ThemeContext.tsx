import React, { createContext, useContext, useEffect, useState } from 'react';

type Theme = 'light' | 'dark';
type TextSize = 'small' | 'medium' | 'large' | 'xl';

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  textSize: TextSize;
  setTextSize: (size: TextSize) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme>(() => {
    const stored = localStorage.getItem('theme');
    return (stored as Theme) || 'light';
  });

  const [textSize, setTextSize] = useState<TextSize>(() => {
    const stored = localStorage.getItem('textSize');
    return (stored as TextSize) || 'medium';
  });

  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove('light', 'dark');
    root.classList.add(theme);
    localStorage.setItem('theme', theme);
  }, [theme]);

  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove('text-small', 'text-medium', 'text-large', 'text-xl');
    root.classList.add(`text-${textSize}`);
    localStorage.setItem('textSize', textSize);
  }, [textSize]);

  return (
    <ThemeContext.Provider value={{ theme, setTheme, textSize, setTextSize }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}