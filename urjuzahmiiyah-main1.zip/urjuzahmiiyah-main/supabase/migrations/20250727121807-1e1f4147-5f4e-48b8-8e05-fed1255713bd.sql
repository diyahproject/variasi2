-- Add missing hijri years
INSERT INTO public.hijri_years (year_number, year_name, description, is_active) VALUES 
(-53, 'Tahun Gajah', 'Tahun kelahiran Nabi Muhammad SAW', true),
(-13, 'Sebelum Kenabian', 'Masa sebelum diangkat menjadi Rasul', true),
(11, '11 Hijriah', 'Tahun wafat Nabi Muhammad SAW dan masa Khalifah Abu Bakar', true);