-- Create admin users table for authentication
CREATE TABLE public.admin_users (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  whatsapp_number TEXT,
  last_login TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create hero section table
CREATE TABLE public.hero_sections (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  subtitle TEXT,
  cta_text TEXT,
  cta_link TEXT,
  background_image TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create hijri years table for timeline
CREATE TABLE public.hijri_years (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  year_number INTEGER UNIQUE NOT NULL,
  year_name TEXT,
  description TEXT,
  image_url TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create categories table
CREATE TABLE public.categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  image_url TEXT,
  badge_text TEXT,
  is_active BOOLEAN DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create events table
CREATE TABLE public.events (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  subtitle TEXT,
  hijri_year INTEGER,
  hijri_month TEXT,
  location TEXT,
  duration TEXT,
  participants TEXT[],
  description TEXT NOT NULL,
  trivia JSONB[],
  event_references JSONB[],
  image_url TEXT,
  latitude DECIMAL,
  longitude DECIMAL,
  category_id UUID,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  FOREIGN KEY (hijri_year) REFERENCES public.hijri_years(year_number),
  FOREIGN KEY (category_id) REFERENCES public.categories(id)
);

-- Create FAQ table
CREATE TABLE public.faqs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  is_active BOOLEAN DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create feedback table
CREATE TABLE public.feedback (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT,
  email TEXT,
  message TEXT NOT NULL,
  is_read BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create about us table
CREATE TABLE public.about_us (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  team_info JSONB,
  mission TEXT,
  is_active BOOLEAN DEFAULT true,
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create welcome popup table
CREATE TABLE public.welcome_popup (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  is_active BOOLEAN DEFAULT true,
  lottie_url TEXT,
  cta_text TEXT,
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.hero_sections ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.hijri_years ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.faqs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.about_us ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.welcome_popup ENABLE ROW LEVEL SECURITY;

-- Create policies for public read access (for main app)
CREATE POLICY "Public can view active hero sections" ON public.hero_sections
FOR SELECT USING (is_active = true);

CREATE POLICY "Public can view active hijri years" ON public.hijri_years
FOR SELECT USING (is_active = true);

CREATE POLICY "Public can view active categories" ON public.categories
FOR SELECT USING (is_active = true);

CREATE POLICY "Public can view active events" ON public.events
FOR SELECT USING (is_active = true);

CREATE POLICY "Public can view active faqs" ON public.faqs
FOR SELECT USING (is_active = true);

CREATE POLICY "Public can view active about us" ON public.about_us
FOR SELECT USING (is_active = true);

CREATE POLICY "Public can view active welcome popup" ON public.welcome_popup
FOR SELECT USING (is_active = true);

-- Allow public to insert feedback
CREATE POLICY "Anyone can submit feedback" ON public.feedback
FOR INSERT WITH CHECK (true);

-- Insert initial data
INSERT INTO public.hero_sections (title, subtitle, cta_text, cta_link) VALUES 
('Sejarah Islam', 'Menelusuri Jejak Peradaban Umat Islam', 'Jelajahi Sejarah', '/timeline');

INSERT INTO public.hijri_years (year_number, year_name, description) VALUES 
(1, '1 Hijriah', 'Tahun Hijrah Rasulullah SAW ke Madinah'),
(2, '2 Hijriah', 'Tahun Perang Badr dan pembentukan masyarakat Islam'),
(3, '3 Hijriah', 'Tahun Perang Uhud'),
(4, '4 Hijriah', 'Tahun pembuangan Bani Nadhir'),
(5, '5 Hijriah', 'Tahun Perang Khandaq (Ahzab)');

INSERT INTO public.categories (name, description, badge_text) VALUES 
('Periode Makkah', 'Sejarah Islam di Makkah sebelum Hijrah', 'Makkah'),
('Periode Madinah', 'Sejarah Islam di Madinah setelah Hijrah', 'Madinah'),
('Perang & Penaklukan', 'Peperangan dan penaklukan dalam sejarah Islam', 'Jihad'),
('Khalifah Rasyidin', 'Masa pemerintahan empat khalifah pertama', 'Khulafa'),
('Dinasti Umayyah', 'Masa pemerintahan Bani Umayyah', 'Umayyah'),
('Dinasti Abbasiyah', 'Masa pemerintahan Bani Abbas', 'Abbasiyah');

INSERT INTO public.welcome_popup (lottie_url, cta_text) VALUES 
('https://assets5.lottiefiles.com/packages/lf20_jcikwtux.json', 'Mulai Jelajahi');

INSERT INTO public.about_us (title, content, mission) VALUES 
('Tentang Kami', 'Kami adalah tim yang berdedikasi untuk menyebarkan pengetahuan sejarah Islam dengan cara yang modern dan mudah diakses.', 'Menyebarkan pengetahuan sejarah Islam kepada generasi muda dengan teknologi modern.');

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_admin_users_updated_at BEFORE UPDATE ON public.admin_users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_hero_sections_updated_at BEFORE UPDATE ON public.hero_sections FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_hijri_years_updated_at BEFORE UPDATE ON public.hijri_years FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_categories_updated_at BEFORE UPDATE ON public.categories FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_events_updated_at BEFORE UPDATE ON public.events FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_faqs_updated_at BEFORE UPDATE ON public.faqs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_about_us_updated_at BEFORE UPDATE ON public.about_us FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_welcome_popup_updated_at BEFORE UPDATE ON public.welcome_popup FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();