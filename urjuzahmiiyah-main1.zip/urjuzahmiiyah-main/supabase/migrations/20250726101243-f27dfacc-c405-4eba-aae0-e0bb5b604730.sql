-- Insert dummy events for testing the Fase page functionality
INSERT INTO public.events (
  title, subtitle, description, hijri_year, hijri_month, location, duration, 
  participants, image_url, trivia, event_references, latitude, longitude, category_id
) VALUES 
-- Events for Periode Makkah
(
  'Kelahiran Nabi Muhammad SAW',
  'Tahun Gajah - Kelahiran Rasulullah',
  'Muhammad ibn Abdullah lahir di Makkah pada bulan Rabiul Awwal tahun Gajah. Beliau lahir dalam keadaan yatim, ayahnya Abdullah telah meninggal sebelum kelahirannya. Kelahiran beliau ditandai dengan berbagai peristiwa mulia dan tanda-tanda kebesaran yang akan datang.',
  -53, 'Rabiul Awwal', 'Makkah', '1 hari', 
  ARRAY['Abdullah ibn Abdul Muttalib', 'Aminah binti Wahab', 'Abdul Muttalib'],
  'https://images.unsplash.com/photo-1564769625905-50e93615e769?w=400&h=300&fit=crop',
  ARRAY['{"text": "Tahun kelahiran disebut Tahun Gajah karena serangan Abrahah dengan gajah"}', '{"text": "Banyak tanda-tanda ajaib terjadi saat kelahiran"}']::jsonb[],
  ARRAY['{"title": "Sirah Nabawiyah - Ibn Ishaq"}', '{"title": "Ar-Rahiq Al-Makhtum - Mubarakfuri"}']::jsonb[],
  21.4225, 39.8262, '82c403ba-c39a-489a-b1da-a02a33d511cf'
),
(
  'Wahyu Pertama di Gua Hira',
  'Iqra - Permulaan Kenabian',
  'Pada usia 40 tahun, Nabi Muhammad SAW menerima wahyu pertama dari Allah SWT melalui Malaikat Jibril di Gua Hira. Wahyu pertama yang turun adalah Surah Al-Alaq ayat 1-5. Peristiwa ini menandai dimulainya misi kenabian dan risalah Islam.',
  -13, 'Ramadhan', 'Gua Hira, Makkah', '1 hari',
  ARRAY['Nabi Muhammad SAW', 'Malaikat Jibril', 'Khadijah binti Khuwailid'],
  'https://images.unsplash.com/photo-1518621012420-9c0d8b96b4ad?w=400&h=300&fit=crop',
  ARRAY['{"text": "Gua Hira terletak di Jabal An-Nur setinggi 634 meter"}', '{"text": "Nabi sering berkhalwat di gua ini sebelum diangkat menjadi rasul"}']::jsonb[],
  ARRAY['{"title": "Shahih Bukhari - Kitab Bada al-Wahyi"}', '{"title": "Sirah Nabawiyah - Ibn Hisham"}']::jsonb[],
  21.4584, 39.8648, '82c403ba-c39a-489a-b1da-a02a33d511cf'
),

-- Events for Periode Madinah  
(
  'Hijrah ke Madinah',
  'Perpindahan Bersejarah ke Yatsrib',
  'Hijrah Nabi Muhammad SAW dari Makkah ke Madinah merupakan peristiwa bersejarah yang menjadi awal tahun Hijriah. Perjalanan ini dilakukan secara rahasia bersama Abu Bakar ash-Shiddiq untuk menghindari pengejaran kaum Quraisy. Hijrah menandai dimulainya era baru penyebaran Islam.',
  1, 'Rabiul Awwal', 'Madinah', '8 hari perjalanan',
  ARRAY['Nabi Muhammad SAW', 'Abu Bakar ash-Shiddiq', 'Abdullah ibn Abi Bakr', 'Amir ibn Fuhairah'],
  'https://images.unsplash.com/photo-1580479767115-70a0b297e4d7?w=400&h=300&fit=crop',
  ARRAY['{"text": "Perjalanan dilakukan melalui jalur tidak biasa untuk mengelabui pengejaran"}', '{"text": "Bersembunyi di Gua Tsur selama 3 hari"}']::jsonb[],
  ARRAY['{"title": "Sirah Nabawiyah - Ibn Ishaq"}', '{"title": "Fiqh as-Sirah - Muhammad al-Ghazali"}']::jsonb[],
  24.4697, 39.6142, 'f029566b-4152-46b6-bf31-55e566a381c9'
),
(
  'Pembangunan Masjid Nabawi',
  'Masjid Pertama di Madinah',
  'Setelah tiba di Madinah, Nabi Muhammad SAW membangun Masjid Nabawi yang menjadi pusat aktivitas keagamaan, sosial, dan politik umat Islam. Masjid ini dibangun di atas tanah yang dibeli dari dua anak yatim bernama Sahl dan Suhail.',
  1, 'Rabiul Akhir', 'Madinah', '7 bulan',
  ARRAY['Nabi Muhammad SAW', 'Sahl ibn Rafi', 'Suhail ibn Rafi', 'Para Muhajirin dan Anshar'],
  'https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?w=400&h=300&fit=crop',
  ARRAY['{"text": "Masjid pertama yang dibangun dengan mihrab dan mimbar"}', '{"text": "Menjadi tempat tinggal Nabi dan pusat pemerintahan"}']::jsonb[],
  ARRAY['{"title": "Tarikh Tabari"}', '{"title": "Sirah Nabawiyah - Ibn Hisham"}']::jsonb[],
  24.4673, 39.6108, 'f029566b-4152-46b6-bf31-55e566a381c9'
),

-- Events for Perang & Penaklukan
(
  'Perang Badr',
  'Kemenangan Pertama Umat Islam',
  'Perang Badr adalah perang pertama yang dimenangkan umat Islam melawan kaum Quraisy. Meskipun jumlah pasukan Muslim hanya 313 orang melawan 1000 pasukan Quraisy, Allah memberikan kemenangan yang menakjubkan. Perang ini terjadi pada 17 Ramadhan tahun ke-2 Hijriah.',
  2, 'Ramadhan', 'Badr, Arab Saudi', '1 hari',
  ARRAY['Nabi Muhammad SAW', 'Abu Bakar', 'Umar ibn Khattab', 'Ali ibn Abi Thalib', 'Hamzah ibn Abdul Muttalib'],
  'https://images.unsplash.com/photo-1551632811-561732d1e306?w=400&h=300&fit=crop',
  ARRAY['{"text": "313 pasukan Muslim menghadapi 1000 pasukan Quraisy"}', '{"text": "70 musuh terbunuh dan 70 ditawan"}']::jsonb[],
  ARRAY['{"title": "Shahih Bukhari - Kitab Maghazi"}', '{"title": "Tafsir Ibn Katsir - Surah Ali Imran"}']::jsonb[],
  23.7367, 38.7684, '5fa585be-a47c-4f7a-8a84-8971f8240a1e'
),
(
  'Perang Uhud',
  'Ujian Besar bagi Umat Islam',
  'Perang Uhud terjadi sebagai balasan kaum Quraisy atas kekalahan mereka di Badr. Awalnya umat Islam unggul, namun kemudian mengalami kemunduran karena sebagian pasukan pemanah meninggalkan posisi. Nabi Muhammad SAW terluka dalam perang ini, namun umat Islam berhasil bertahan.',
  3, 'Syawwal', 'Uhud, Madinah', '1 hari',
  ARRAY['Nabi Muhammad SAW', 'Hamzah ibn Abdul Muttalib', 'Abdullah ibn Jahsy', 'Khalid ibn Walid', 'Abu Sufyan'],
  'https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=400&h=300&fit=crop',
  ARRAY['{"text": "Hamzah ibn Abdul Muttalib gugur sebagai syahid"}', '{"text": "Khalid ibn Walid memimpin serangan balik kaum Quraisy"}']::jsonb[],
  ARRAY['{"title": "Sirah Nabawiyah - Ibn Ishaq"}', '{"title": "Maghazi Waqidi"}']::jsonb[],
  24.4858, 39.5847, '5fa585be-a47c-4f7a-8a84-8971f8240a1e'
),

-- Events for Khalifah Rasyidin
(
  'Terpilihnya Abu Bakar sebagai Khalifah',
  'Khalifah Pertama Pengganti Rasulullah',
  'Setelah wafatnya Nabi Muhammad SAW, umat Islam berkumpul di Saqifah Bani Sa`idah untuk memilih pemimpin. Setelah diskusi panjang antara Muhajirin dan Anshar, Abu Bakar ash-Shiddiq terpilih sebagai Khalifah pertama. Beliau memimpin dengan bijaksana dan berhasil menyatukan kembali umat Islam.',
  11, 'Rabiul Awwal', 'Madinah', '1 hari',
  ARRAY['Abu Bakar ash-Shiddiq', 'Umar ibn Khattab', 'Abu Ubaidah ibn Jarrah', 'Sa`d ibn Ubadah'],
  'https://images.unsplash.com/photo-1557804506-669a67965ba0?w=400&h=300&fit=crop',
  ARRAY['{"text": "Gelar \"Khalifah Rasulullah\" pertama kali digunakan"}', '{"text": "Peristiwa di Saqifah Bani Sa`idah menjadi dasar sistem khalifah"}']::jsonb[],
  ARRAY['{"title": "Tarikh Tabari"}', '{"title": "Al-Bidayah wan Nihayah - Ibn Katsir"}']::jsonb[],
  24.4697, 39.6142, 'a04f0690-4244-4453-b7f4-8cf70c9eb862'
),
(
  'Perang Riddah',
  'Pemberantasan Kemurtadan Massal',
  'Setelah wafatnya Nabi Muhammad SAW, banyak suku Arab yang murtad dan menolak membayar zakat. Abu Bakar dengan tegas mengirim pasukan untuk menumpas pemberontakan ini. Perang Riddah dipimpin oleh Khalid ibn Walid dan berhasil mengembalikan persatuan umat Islam.',
  11, 'Jumadil Ula', 'Jazirah Arab', '1 tahun',
  ARRAY['Abu Bakar ash-Shiddiq', 'Khalid ibn Walid', 'Ikrimah ibn Abi Jahl', 'Musailamah al-Kadzdzab'],
  'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=300&fit=crop',
  ARRAY['{"text": "Khalid ibn Walid mendapat julukan \"Saif Allah al-Maslul\""}', '{"text": "Berhasil mengamankan seluruh Jazirah Arab"}']::jsonb[],
  ARRAY['{"title": "Futuh al-Buldan - Al-Baladhuri"}', '{"title": "Tarikh Tabari"}']::jsonb[],
  24.7136, 46.6753, 'a04f0690-4244-4453-b7f4-8cf70c9eb862'
);

-- Update categories with images for better visual
UPDATE public.categories 
SET image_url = 'https://images.unsplash.com/photo-1564769625905-50e93615e769?w=400&h=300&fit=crop'
WHERE name = 'Periode Makkah';

UPDATE public.categories 
SET image_url = 'https://images.unsplash.com/photo-1580479767115-70a0b297e4d7?w=400&h=300&fit=crop'
WHERE name = 'Periode Madinah';

UPDATE public.categories 
SET image_url = 'https://images.unsplash.com/photo-1551632811-561732d1e306?w=400&h=300&fit=crop'
WHERE name = 'Perang & Penaklukan';

UPDATE public.categories 
SET image_url = 'https://images.unsplash.com/photo-1557804506-669a67965ba0?w=400&h=300&fit=crop'
WHERE name = 'Khalifah Rasyidin';