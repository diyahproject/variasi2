-- Add admin access policies for the new tables
CREATE POLICY "Admin can manage team members" 
ON public.team_members 
FOR ALL 
USING (true)
WITH CHECK (true);

CREATE POLICY "Admin can manage downloads" 
ON public.downloads 
FOR ALL 
USING (true)
WITH CHECK (true);

CREATE POLICY "Admin can manage external sources" 
ON public.external_sources 
FOR ALL 
USING (true)
WITH CHECK (true);

-- Fix search path for existing function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;