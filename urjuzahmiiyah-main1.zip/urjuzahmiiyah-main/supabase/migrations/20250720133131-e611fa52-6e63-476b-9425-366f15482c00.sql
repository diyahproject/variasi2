-- Enable realtime for all tables to support real-time updates
ALTER TABLE public.hero_sections REPLICA IDENTITY FULL;
ALTER TABLE public.hijri_years REPLICA IDENTITY FULL;
ALTER TABLE public.categories REPLICA IDENTITY FULL;
ALTER TABLE public.events REPLICA IDENTITY FULL;
ALTER TABLE public.faqs REPLICA IDENTITY FULL;
ALTER TABLE public.feedback REPLICA IDENTITY FULL;
ALTER TABLE public.about_us REPLICA IDENTITY FULL;
ALTER TABLE public.welcome_popup REPLICA IDENTITY FULL;

-- Add tables to realtime publication
ALTER PUBLICATION supabase_realtime ADD TABLE public.hero_sections;
ALTER PUBLICATION supabase_realtime ADD TABLE public.hijri_years;
ALTER PUBLICATION supabase_realtime ADD TABLE public.categories;
ALTER PUBLICATION supabase_realtime ADD TABLE public.events;
ALTER PUBLICATION supabase_realtime ADD TABLE public.faqs;
ALTER PUBLICATION supabase_realtime ADD TABLE public.feedback;
ALTER PUBLICATION supabase_realtime ADD TABLE public.about_us;
ALTER PUBLICATION supabase_realtime ADD TABLE public.welcome_popup;