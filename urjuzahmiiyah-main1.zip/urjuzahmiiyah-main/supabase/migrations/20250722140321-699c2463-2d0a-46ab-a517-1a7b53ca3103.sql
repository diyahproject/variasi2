-- Create user roles enum
CREATE TYPE public.user_role AS ENUM ('superadmin', 'admin');

-- Create admin users table with proper authentication
CREATE TABLE public.admin_users (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role user_role NOT NULL DEFAULT 'admin',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  last_login TIMESTAMP WITH TIME ZONE
);

-- Create OTP sessions table
CREATE TABLE public.otp_sessions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES admin_users(id) ON DELETE CASCADE,
  otp_code TEXT NOT NULL,
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  is_used BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create content management tables
CREATE TABLE public.content_sections (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  section_key TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  description TEXT,
  content JSONB NOT NULL DEFAULT '{}',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create media uploads table
CREATE TABLE public.media_uploads (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  filename TEXT NOT NULL,
  original_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size INTEGER NOT NULL,
  mime_type TEXT NOT NULL,
  uploaded_by UUID REFERENCES admin_users(id),
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.otp_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.content_sections ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.media_uploads ENABLE ROW LEVEL SECURITY;

-- RLS Policies for admin_users (only superadmin can manage users)
CREATE POLICY "Superadmin can manage all users" ON public.admin_users
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.admin_users a 
      WHERE a.id = auth.uid()::uuid AND a.role = 'superadmin' AND a.is_active = true
    )
  );

CREATE POLICY "Users can view their own profile" ON public.admin_users
  FOR SELECT USING (id = auth.uid()::uuid AND is_active = true);

-- RLS Policies for content_sections (all admins can manage content)
CREATE POLICY "Admins can manage content" ON public.content_sections
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.admin_users a 
      WHERE a.id = auth.uid()::uuid AND a.is_active = true
    )
  );

CREATE POLICY "Public can view active content" ON public.content_sections
  FOR SELECT USING (is_active = true);

-- RLS Policies for media_uploads (all admins can manage media)
CREATE POLICY "Admins can manage media" ON public.media_uploads
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.admin_users a 
      WHERE a.id = auth.uid()::uuid AND a.is_active = true
    )
  );

CREATE POLICY "Public can view active media" ON public.media_uploads
  FOR SELECT USING (is_active = true);

-- RLS Policies for otp_sessions (users can only access their own OTP)
CREATE POLICY "Users can access their own OTP" ON public.otp_sessions
  FOR ALL USING (user_id = auth.uid()::uuid);

-- Create triggers for updated_at columns
CREATE TRIGGER update_admin_users_updated_at
  BEFORE UPDATE ON public.admin_users
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_content_sections_updated_at
  BEFORE UPDATE ON public.content_sections
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default content sections
INSERT INTO public.content_sections (section_key, title, description, content) VALUES
('hero_section', 'Hero Section', 'Main hero section content', '{"title": "Sejarah Islam", "subtitle": "Menelusuri Jejak Peradaban Islam", "cta_text": "Jelajahi Timeline", "background_image": "", "main_image": ""}'),
('about_section', 'About Section', 'About page content', '{"title": "Tentang Kami", "content": "Platform pembelajaran sejarah Islam yang komprehensif", "mission": "Menyebarkan pengetahuan sejarah Islam"}'),
('welcome_popup', 'Welcome Popup', 'Welcome popup content', '{"title": "Selamat Datang", "content": "Selamat datang di platform sejarah Islam", "is_enabled": false}');

-- Insert default superadmin (password: Admin123!)
INSERT INTO public.admin_users (username, email, password_hash, role) VALUES
('superadmin', 'admin@example.com', '$2a$10$8K1p/a0dUrXwl5o.6L5uQuFBr8y6n5yV4GrOQxT3d7p7Hj.Ft7LW6', 'superadmin');