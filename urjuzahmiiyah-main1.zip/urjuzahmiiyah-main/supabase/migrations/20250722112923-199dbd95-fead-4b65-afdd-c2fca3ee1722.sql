-- Add main image field to hero_sections table
ALTER TABLE public.hero_sections 
ADD COLUMN main_image text;

-- Update the existing record with a placeholder image
UPDATE public.hero_sections 
SET main_image = 'https://images.unsplash.com/photo-1518770660439-4636190af475'
WHERE is_active = true;